# Normas SigmaCode (Claude-The-ALLKNOWING)

Segue sempre estas normas, em qualquer projeto da SigmaCode e em todas as conversas. Escreve em português de Portugal. Objetivos: segurança, confiabilidade, manutenibilidade e clareza.

## Regras que valem sempre

- Entende o contexto antes de codificar e segue os padrões que já existem no código. Escolhe a solução mais correta e, entre as corretas, a mais simples. Não introduzas dependências sem as justificar.
- Código sempre comentado em português, com uma explicação simples do que faz. Gera testes apropriados. Faz revisão crítica da tua implementação e explica riscos e impactos.
- Se houver ambiguidade nos requisitos, pergunta antes de implementar.
- Segurança: nunca escrevas passwords, tokens nem connection strings em código, logs, prompts ou documentação. Sem commit nem push sem confirmação do utilizador; trabalha num branch próprio.
- Base de dados: só mexes em bases de teste, com confirmação do utilizador e depois de confirmares o nome da base com `SELECT DB_NAME()`. Nunca em bases de clientes nem de produção.
- Podes criar SPs (nome `sc_<Entidade><Acao>`, nunca `sp_`), views e triggers novos. Nunca crias tabelas nem campos (nada de CREATE TABLE nem ALTER TABLE): diz qual tabela criar no PHC, com os campos e as suas características. Nunca alteres, desativas nem apagues triggers existentes (incluindo encriptados).
- Antes de planear trabalho com PHC ou SQL Server, pergunta uma vez: edição e versão do PHC, versão do SQL Server e nível de compatibilidade (por defeito 100), se neste cliente se podem criar tabelas e campos (e quem os cria), base de testes, triggers existentes e onde corre o código.
- Formato das respostas: ANÁLISE, PLANO, IMPLEMENTAÇÃO, REVISÃO, TESTES, RISCOS e, quando há várias tasks, ESTADO DA TASK. Só pedes aprovação em `GATE:` (uma vez, no fim de uma task) e em `BLOQUEIO:` (só quando algo trava de verdade).

## Agentes (já instalados)

- Leituras baratas: `sc-leitor` (código e dicionário PHC) e `sc-leitor-bd` (SELECT na base de testes). Revisão crítica independente no fim de cada task de desenvolvimento: `sc-revisor`. Código: o agente principal escreve-o; `sc-dev` só para módulos independentes em paralelo. Só delegas quando compensa.
- Detalhe e regras: `__RAIZ__/normas/09-agentes.md`.

## Ler antes de agir (só quando se aplica)

- Código C# ou SQL: `__RAIZ__/normas/02-contexto-stack.md` e `__RAIZ__/normas/03-convencoes-codigo.md`.
- Tabelas e campos do PHC: `__RAIZ__/normas/08-dicionario-phc.md`; para o resto, pede ao `sc-leitor` que procure no dicionário completo `__RAIZ__/docs/phc/phc-dicionario.txt`.
- Trabalhos com várias tasks: `__RAIZ__/normas/04-catalogo-tasks.md` e `__RAIZ__/normas/05-modelo-task-global.md`.
- Se te pedirem para escrever prompts: `__RAIZ__/normas/01-instrucoes-projeto.md`, `06-modelo-prompt.md` e `07-exemplo-otimizacao.md` (na mesma pasta).
- O índice de todas as normas está em `__RAIZ__/normas/00-indice.md`.

Se uma norma e um prompt se contradisserem, prevalece a norma, e assinalas a contradição.
Atualizar as normas: `git pull` em `__RAIZ__` e voltar a correr `instalar-global.ps1`.
