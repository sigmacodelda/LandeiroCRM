# Claude-The-ALLKNOWING

Repositório privado da equipa SigmaCode com as normas, os agentes e o dicionário PHC que o Claude Code usa em todas as conversas. Não tem credenciais, IPs nem tokens e nunca deve ter.

## Instalar (uma vez por máquina)

Cola no Claude Code:

```text
Clona <URL do repositório>.git para C:\_SigmaRepos\Claude-The-ALLKNOWING (se a pasta já existir, faz git pull) e corre powershell -NoProfile -ExecutionPolicy RemoteSigned -File C:\_SigmaRepos\Claude-The-ALLKNOWING\instalar-global.ps1. No fim diz-me se o teste do hook passou.
```

Pré-requisitos: Windows com PowerShell, `git`, acesso a este repositório no GitHub e o Claude Code. A palavra-passe da base de testes fica na variável de ambiente `SQLCMDPASSWORD` da máquina, nunca em ficheiros. A mesma linha serve para atualizar.

O que o instalador faz em `~/.claude/`: escreve `sigma-normas.md`, acrescenta um bloco gerido a `CLAUDE.md` que o importa, copia os agentes `sc-*` para `agents/`, acrescenta `model: opusplan` e o limite de aninhamento a `settings.json` (só se faltarem; guarda uma cópia `settings.json.bak-sigma`) e corre o teste do hook. A partir daí, qualquer conversa do Claude Code, em qualquer projeto, já tem as normas e os agentes.

## Conteúdo

- `CLAUDE.md`: as normas, resumidas. É o que o Claude lê sempre.
- `normas/`: as 9 partes das normas, uma por ficheiro (geradas de `projeto/projeto-sigmacode.md`).
- `agents/`: `sc-leitor`, `sc-leitor-bd`, `sc-revisor` e `sc-dev`.
- `hooks/`: hook de SQL só-leitura, o seu teste e `bases-permitidas.txt`.
- `docs/phc/`: dicionário do PHC (`phc-dicionario.txt`, `phc-diretorio.txt`) e `gerar-dicionario.py`.
- `projeto/`: o que se carrega no Projeto Claude (`instrucoes-para-colar.md` e `projeto-sigmacode.md`). É a versão de referência.
- `tools/dividir-partes.py` e `instalar-global.ps1`.

## Como se muda uma regra

1. Editar `projeto/projeto-sigmacode.md` e subir a versão no topo.
2. Correr `python tools/dividir-partes.py` (regenera `normas/`).
3. Se a regra vale sempre, atualizar também o `CLAUDE.md`.
4. Commit e push. Quem mantém o Projeto Claude volta a carregar `projeto/projeto-sigmacode.md` e atualiza as instruções.
5. Cada pessoa volta a correr a linha de instalação.

## Bases de teste

Acrescenta a base de testes de cada cliente a `hooks/bases-permitidas.txt` (uma por linha, por commit). Bases só tuas: `hooks/bases-permitidas.local.txt` (fora do git). Só bases de teste, nunca de produção.

## Dicionário PHC novo

`python docs/phc/gerar-dicionario.py livro.xlsx docs/phc` (precisa de `pip install openpyxl`).
