#!/usr/bin/env python3
# Gera o dicionário PHC compacto a partir do livro Excel do PHC (colunas: Tabela, Nome Tabela,
# Campo, Nome Campo, Tipo Campo, Comprimento Campo, Casas Decimais).
#
# Uso:   python gerar-dicionario.py livro.xlsx [pasta_de_saida]
# Requer: pip install openpyxl
# Saída: phc-dicionario.txt (uma secção por tabela, uma linha por campo) e phc-diretorio.txt.
#
# O que remove (para ficar só o necessário):
#   - linhas repetidas (o livro repete cada campo muitas vezes);
#   - tabelas "buffer" (cópias temporárias das tabelas reais);
#   - campos de auditoria (OUSRINIS, OUSRDATA, OUSRHORA, USRINIS, USRDATA, USRHORA, MARCADA);
#   - campos derivados de datas (D_, M_, S_, T_, A_ e M_ALFA_ + nome do campo data);
#   - campos sem descrição útil ("?", "Campo");
#   - a versão em escudos (PTE) de valores que têm versão em euros (prefixo E, N18.5 -> N19.6):
#     fica só o campo em euros, com a indicação do campo legado.
import collections
import os
import re
import sys

import openpyxl

AUDITORIA = {"OUSRINIS", "OUSRDATA", "OUSRHORA", "USRINIS", "USRDATA", "USRHORA", "MARCADA"}
# Tabelas de interface, portal e afins: ficam fora do diretório (continuam no dicionário completo).
FORA_DO_DIRETORIO = re.compile(
    r"web|portal|extranet|blog|chat|dashboard|monitor|multim[eé]dia|newsletter|leil|ecr[ãa]|faq|banner|"
    r"galeria|f[óo]rum|hits|favorito|prefer[êe]ncias|menu|apresenta|coverflex|recrutamento|"
    r"balan[çc]o social|alerta|assistente|inqu[ée]rito|cadastro de registos|"
    r"comunica[çc][ãa]o com o utilizador|links|an[áa]lises? multidimensiona|an[áa]lises? avan[çc]ada|"
    r"mapas?/|conte[úu]dos|implementation", re.I)


def ler_livro(caminho):
    """Lê o livro e devolve (campos por tabela, descrição por tabela), sem repetições."""
    folha = openpyxl.load_workbook(caminho, read_only=True).worksheets[0]
    campos = collections.OrderedDict()
    nomes = {}
    for i, linha in enumerate(folha.iter_rows(values_only=True)):
        if i == 0:
            continue  # cabeçalho
        tabela, nome_tabela, campo, descricao, tipo, comp, dec = (list(linha) + [None] * 7)[:7]
        if not tabela:
            continue
        nomes.setdefault(tabela, nome_tabela or "")
        if not campo:
            continue  # linhas sem campo descrevem filtros de listagens
        campos.setdefault(tabela, collections.OrderedDict()).setdefault(
            campo, ((descricao or "").strip(), tipo or "?", int(comp or 0), int(dec or 0)))
    return campos, nomes


def tipo_curto(tipo, comp, dec):
    """C55, N10, N18.5, L, D, M."""
    if tipo == "C":
        return "C%d" % comp
    if tipo == "N":
        return "N%d.%d" % (comp, dec) if dec else "N%d" % comp
    return tipo


def limpar(campos, nomes):
    """Aplica as remoções descritas no topo. Devolve (tabelas limpas, legados, contagens)."""
    limpo = collections.OrderedDict()
    legados = {}
    contagem = collections.Counter()
    for tabela, cs in campos.items():
        if re.search(r"buffer", nomes.get(tabela, ""), re.I):
            contagem["buffer"] += len(cs)
            continue
        novo = collections.OrderedDict()
        legado = {}
        # Se o campo em euros (E) não tem descrição, herda a do campo legado correspondente.
        cs = collections.OrderedDict(cs)
        for c in list(cs):
            g = cs.get("E" + c)
            if g and g[0] in ("?", "", "Campo") and cs[c][0] not in ("?", "", "Campo"):
                cs["E" + c] = (cs[c][0],) + g[1:]
        for c, (desc, tipo, comp, dec) in cs.items():
            if c in AUDITORIA:
                contagem["auditoria"] += 1
                continue
            if desc in ("?", "", "Campo"):
                contagem["sem_descricao"] += 1
                continue
            m = re.match(r"^(M_ALFA_|A_|D_|M_|S_|T_)(.+)$", c)
            if m and m.group(2) in cs and cs[m.group(2)][1] == "D":
                contagem["parte_de_data"] += 1
                continue
            # Campo legado em escudos: existe o gémeo E (euros) com +1 de comprimento e +1 casa decimal.
            g = cs.get("E" + c)
            if g and tipo == "N" and g[1] == "N" and g[2] == comp + 1 and g[3] == dec + 1:
                contagem["legado_pte"] += 1
                legado["E" + c] = c
                continue
            novo[c] = (desc, tipo, comp, dec)
        limpo[tabela] = novo
        legados[tabela] = legado
    return limpo, legados, contagem


def linha_campo(c, v, legado):
    desc, tipo, comp, dec = v
    nota = " [legado PTE: %s]" % legado[c] if c in legado else ""
    return "%s %s %s%s" % (c, tipo_curto(tipo, comp, dec), desc[:70], nota)


def main():
    if len(sys.argv) < 2:
        sys.exit("Uso: python gerar-dicionario.py livro.xlsx [pasta_de_saida]")
    saida = sys.argv[2] if len(sys.argv) > 2 else "."
    campos, nomes = ler_livro(sys.argv[1])
    limpo, legados, contagem = limpar(campos, nomes)
    with open(os.path.join(saida, "phc-dicionario.txt"), "w", encoding="utf-8") as f:
        for t, cs in limpo.items():
            if not cs:
                continue
            f.write("## %s — %s\n" % (t, nomes[t]))
            for c, v in cs.items():
                f.write(linha_campo(c, v, legados[t]) + "\n")
    with open(os.path.join(saida, "phc-diretorio.txt"), "w", encoding="utf-8") as f:
        for t, cs in limpo.items():
            if cs and not FORA_DO_DIRETORIO.search(nomes[t]):
                f.write("%s %s\n" % (t, nomes[t][:45]))
    print("campos úteis: %d; removidos: %s" % (sum(len(v) for v in limpo.values()), dict(contagem)))


if __name__ == "__main__":
    main()
