﻿# Instala as normas e os agentes SigmaCode ao nível do utilizador (pasta ~/.claude), para valerem em
# todas as conversas do Claude Code, em qualquer projeto. Pode correr-se outra vez para atualizar.
# Uso:  powershell -NoProfile -ExecutionPolicy RemoteSigned -File instalar-global.ps1 [-Pull]
# -Pull: faz git pull neste repositório antes de instalar.
# O que escreve em ~/.claude: sigma-normas.md, agents/sc-*.md, um bloco gerido em CLAUDE.md e,
# só se ainda não existirem, as chaves model e env em settings.json (com cópia de segurança).
param([switch]$Pull)

$ErrorActionPreference = 'Stop'
$raiz = $PSScriptRoot
$raizBarras = $raiz -replace '\\', '/'          # caminhos com / para os ficheiros do Claude
$claude = Join-Path $HOME '.claude'
$semBom = New-Object System.Text.UTF8Encoding($false)

# Escreve texto em UTF-8 sem BOM (um BOM estragaria o settings.json).
function Escrever([string]$caminho, [string]$texto) {
    [System.IO.File]::WriteAllText($caminho, $texto, $semBom)
}
# Lê um ficheiro de texto UTF-8 (com ou sem BOM).
function Ler([string]$caminho) { return [System.IO.File]::ReadAllText($caminho, [System.Text.Encoding]::UTF8) }
# Troca o marcador __RAIZ__ pelo caminho real deste repositório.
function Renderizar([string]$texto) { return $texto.Replace('__RAIZ__', $raizBarras) }

if ($Pull) {
    git -C $raiz pull --ff-only
    if ($LASTEXITCODE -ne 0) { throw 'git pull falhou. Resolve o problema e corre outra vez.' }
}

New-Item -ItemType Directory -Force -Path (Join-Path $claude 'agents') | Out-Null

# 1. Normas (CLAUDE.md deste repositório, com os caminhos certos).
Escrever (Join-Path $claude 'sigma-normas.md') (Renderizar (Ler (Join-Path $raiz 'CLAUDE.md')))

# 2. Bloco gerido no CLAUDE.md do utilizador, que importa as normas. O resto do ficheiro não é tocado.
$ficheiro = Join-Path $claude 'CLAUDE.md'
$ini = '<!-- sigma:inicio (gerido por Claude-The-ALLKNOWING; não editar este bloco) -->'
$fim = '<!-- sigma:fim -->'
$bloco = $ini + "`n@~/.claude/sigma-normas.md`n" + $fim
$atual = ''
if (Test-Path $ficheiro) { $atual = Ler $ficheiro }
$padrao = '(?s)<!-- sigma:inicio.*?<!-- sigma:fim -->'
if ($atual -match $padrao) { $novo = [regex]::Replace($atual, $padrao, { param($m) $bloco }) }
else { $novo = ($atual.TrimEnd() + "`n`n" + $bloco + "`n").TrimStart() }
Escrever $ficheiro $novo

# 3. Agentes (os que começam por sc-), com os caminhos certos.
foreach ($a in Get-ChildItem -Path (Join-Path $raiz 'agents') -Filter 'sc-*.md') {
    Escrever (Join-Path $claude ('agents\' + $a.Name)) (Renderizar (Ler $a.FullName))
}

# 4. settings.json: acrescenta model e o limite de aninhamento só se ainda não existirem.
$sp = Join-Path $claude 'settings.json'
try {
    if (Test-Path $sp) {
        if (-not (Test-Path ($sp + '.bak-sigma'))) { Copy-Item $sp ($sp + '.bak-sigma') }   # só guarda a 1.ª cópia
        $cfg = (Ler $sp) | ConvertFrom-Json
    }
    else { $cfg = [pscustomobject]@{} }
    if (-not $cfg.PSObject.Properties['model']) { $cfg | Add-Member -NotePropertyName model -NotePropertyValue 'opusplan' }
    if (-not $cfg.PSObject.Properties['env']) { $cfg | Add-Member -NotePropertyName env -NotePropertyValue ([pscustomobject]@{}) }
    if (-not $cfg.env.PSObject.Properties['CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH']) {
        $cfg.env | Add-Member -NotePropertyName CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH -NotePropertyValue '1'
    }
    Escrever $sp ($cfg | ConvertTo-Json -Depth 20)
}
catch {
    Write-Host "AVISO: não consegui atualizar settings.json ($($_.Exception.Message))."
    Write-Host 'Acrescenta à mão: "model": "opusplan" e env CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH = "1".'
}

# 5. Teste do hook de SQL só-leitura.
& powershell -NoProfile -ExecutionPolicy RemoteSigned -File (Join-Path $raiz 'hooks\testar-hook.ps1')
$hookOk = ($LASTEXITCODE -eq 0)

Write-Host ''
Write-Host "Instalado a partir de $raiz."
Write-Host 'Agentes em ~/.claude/agents, normas em ~/.claude/sigma-normas.md (importadas por ~/.claude/CLAUDE.md).'
Write-Host 'Palavra-passe da base de testes: variável de ambiente SQLCMDPASSWORD (nunca em ficheiros).'
if ($hookOk) { Write-Host 'Teste do hook: OK.' } else { Write-Host 'Teste do hook: FALHOU. Vê as linhas FALHOU acima.'; exit 1 }
