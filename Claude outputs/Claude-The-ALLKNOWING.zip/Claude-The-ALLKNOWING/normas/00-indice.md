# Índice das normas

Cada ficheiro é uma "Parte" do ficheiro único do Projeto Claude. As referências "Parte N" nos textos apontam para estes ficheiros.

- `01-instrucoes-projeto.md`: Parte 1 — Instruções do projeto
- `02-contexto-stack.md`: Parte 2 — Contexto da stack
- `03-convencoes-codigo.md`: Parte 3 — Convenções de código
- `04-catalogo-tasks.md`: Parte 4 — Catálogo de tasks
- `05-modelo-task-global.md`: Parte 5 — Modelo de task global
- `06-modelo-prompt.md`: Parte 6 — Modelo de prompt
- `07-exemplo-otimizacao.md`: Parte 7 — Exemplo de prompt: otimização do acesso a dados da API
- `08-dicionario-phc.md`: Parte 8 — Dicionário de dados do PHC
- `09-agentes.md`: Parte 9 — Agentes (subagentes do Claude Code)
