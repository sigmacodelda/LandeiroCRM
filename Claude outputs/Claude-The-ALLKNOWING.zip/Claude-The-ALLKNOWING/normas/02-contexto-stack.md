# Parte 2 — Contexto da stack

Versão 2.1 · 13/10/2026 · Substitui a v1 (a tua) e a v2 reconstruída.
Estado: parte do teu original, com as correções e as regras novas aplicadas. `[CONFIRMAR]` quer dizer que não tenho certeza e deves validar. `[NOVO]` quer dizer que foi acrescentado na v2 e deves aceitar ou apagar. Sem marca: vem do teu original.

## 1. Como usar esta parte

- É a stack de referência da SigmaCode. Se o pedido for para outro projeto ou outra API, pergunta primeiro (frameworks, base de dados, nível de compatibilidade, dependências) e não assumas o que está aqui.
- Os factos que mudam de cliente para cliente (edição e versão do PHC, nível de compatibilidade, o que se pode criar na base) não são regra aqui: perguntam-se sempre (secção 4). O que for reutilizável fica num ficheiro por cliente, `cliente-<nome>.md`.
- A regra do que o Claude Code pode criar na base de dados está na Parte 1 (fonte única). Aqui ficam só os factos.

## 2. Arquitetura e tecnologias

| Camada | Tecnologia | Repositório |
|---|---|---|
| APP | .NET MAUI | Fora de âmbito: não se altera sem indicação explícita |
| API | ASP.NET Core, .NET 8 | — |
| sServices | .NET Framework 4.8 (C# 7.3) | `C:\_SigmaRepos\sServices` |
| sUtils | .NET Framework 4.8 (C# 7.3) | `C:\_SigmaRepos\sUtils` |
| sigma-phc-dossiers | Destino final das Stored Procedures e da biblioteca C# partilhada (netstandard2.0, Dapper, Microsoft.Data.SqlClient 5.x, Options e Logging.Abstractions) | `C:\_SigmaRepos\sigma-phc-dossiers` |
| Base de dados | PHC em SQL Server 2019 | — |

Fluxo atual: APP → API → sServices → sUtils → Base de dados (PHC). O sServices é chamado pela API para comunicar com o servidor e usa o sUtils. A API referencia a biblioteca sigma-phc-dossiers por ProjectReference (mais tarde passa a pacote NuGet).

Ferramentas: os prompts são usados no Claude Code, com acesso aos repositórios em `C:\_SigmaRepos`.

Trabalho em curso: otimização do acesso a dados da API via Stored Procedures, módulo a módulo e ação a ação, começando pela Logística. As Transferências já foram intervencionadas e vão servir de implementação de referência depois de validadas (exemplo na Parte 7).

## 3. Base de dados PHC: factos gerais

- SQL Server 2019 (15.x), Standard Edition. As bases PHC estão em nível de compatibilidade 100 (SQL Server 2008) e as SPs têm de funcionar nesse nível.
- Cada cliente PHC tem a sua própria base de dados; os objetos são instalados em cada uma.
- Cada tabela do PHC tem uma chave `<tabela>stamp` do tipo `char(25)`, gerada pela aplicação e não pela base de dados. O formato dos stamps lê-se de dados reais, nunca se assume. Exemplo de leitura: `SELECT TOP 10 clstamp, LEN(clstamp), DATALENGTH(clstamp) FROM CL WHERE clstamp <> ''`.
- As tabelas de utilizador começam por `u_`. No cliente Landeiro, lidas diretamente da base, trazem estes campos standard, todos NOT NULL com valor por defeito: `u_<nome>stamp` (char(25), chave), `ousrinis`, `ousrdata`, `ousrhora`, `usrinis`, `usrdata`, `usrhora` e `marcada`. `[CONFIRMAR]` noutros clientes, edições e versões.
- `CL` (clientes) tem uma extensão 1:1 em `CL2` (`cl2.cl2stamp = cl.clstamp`). `[NOVO]` Exemplo tirado da integração Landeiro.
- O PHC tem triggers próprios, por vezes encriptados (no Landeiro, `tr_cl_update` e `tr_cl_delete` em `CL`). Nunca se alteram, desativam, apagam nem reordenam.
- Campos numéricos concatenados com texto precisam de CAST explícito, por exemplo `CAST(cl.no AS varchar(10)) + '-' + CAST(cl.estab AS varchar(3))`. Sem o CAST, o SQL Server tenta converter o texto "-" para número e falha. `[NOVO]`
- `[CONFIRMAR]` O que acontece aos objetos de terceiros (triggers, views, SPs) quando o PHC do cliente é atualizado. Até haver resposta, cada prompt que instale triggers inclui um script de verificação de que continuam ativos e um script de reinstalação.

## 4. Factos por cliente (perguntar sempre)

Preencher e guardar em `cliente-<nome>.md` quando forem reutilizáveis. Nunca incluir credenciais, IPs nem tokens.

| Facto | Como confirmar |
|---|---|
| Edição do PHC (Advanced, Evolution ou outra) e versão | Perguntar ao utilizador. |
| Alojamento (servidor do cliente ou cloud) e acesso direto à base de dados | Perguntar ao utilizador. |
| Versão e edição do SQL Server | Consulta 1, abaixo. |
| Nível de compatibilidade da base | Consulta 1, abaixo. |
| É possível criar tabelas de utilizador e campos novos no PHC? Quem cria? | Perguntar ao utilizador. No Advanced, segundo a indicação da equipa, não é possível criar tabelas. |
| Base de testes: nome, instância, é cópia restaurada? | Perguntar ao utilizador. `SELECT DB_NAME()` antes de qualquer escrita. |
| Triggers nas tabelas envolvidas | Consulta 2, abaixo. Definição NULL quer dizer trigger encriptado. |
| As atualizações do PHC mexem em objetos de terceiros? | Perguntar ao utilizador ou à PHC. |

Consulta 1 (só leitura): versão e nível de compatibilidade.

```sql
SELECT @@VERSION                        AS VersaoCompleta,
       SERVERPROPERTY('ProductVersion') AS Versao,
       SERVERPROPERTY('Edition')        AS Edicao,
       DB_NAME()                        AS BaseDados,
       compatibility_level              AS NivelCompatibilidade
FROM sys.databases
WHERE name = DB_NAME();
```

Consulta 2 (só leitura): triggers de uma tabela (exemplo com `CL`).

```sql
SELECT t.name, t.is_disabled, m.definition
FROM sys.triggers AS t
LEFT JOIN sys.sql_modules AS m ON m.object_id = t.object_id
WHERE t.parent_id = OBJECT_ID('dbo.CL');
```

## 5. Compatibilidade SQL (nível 100)

Regra mantida: o SQL dos prompts tem de funcionar com a base em nível de compatibilidade 100, que é o nível das bases PHC dos clientes SigmaCode (`[CONFIRMAR]` por cliente). O nível 100 usa o estimador de cardinalidade antigo, por isso a performance valida-se em medições reais (secção 7), não só em teoria.

Atenção: a base `LAND2_DEMO` (testes do Landeiro) está em nível 150. Testes que passam lá não provam compatibilidade com o nível 100.

| Funcionalidade | Estado no nível 100 | O que fazer |
|---|---|---|
| CREATE OR ALTER PROCEDURE | Funciona (depende da versão do motor; no SQL Server 2019 está disponível). | Permitido. |
| Tabelas temporárias, variáveis de tabela, CTEs, TRY/CATCH | Funcionam. | Permitidos. |
| XML com `.nodes()` e `.value()` | Funciona. | Forma de passar listas. |
| STRING_SPLIT | Não funciona: exige nível 130 (documentação Microsoft). | Usar XML. |
| OPENJSON | Não funciona: exige nível 130 (documentação Microsoft). | Evitar. |
| JSON_VALUE e restantes funções JSON | A tua v1 diz que exigem 130. `[CONFIRMAR]` A documentação Microsoft só indica OPENJSON como dependente do nível. | Evitar até confirmar. |
| TRY_CONVERT, IIF, CONCAT, FORMAT, OFFSET … FETCH, THROW | Testar antes de usar (SQL Server 2012 em diante). | Só depois de confirmado. Na dúvida: CASE, CONVERT, ROW_NUMBER, RAISERROR. |
| TRY_CAST, STRING_AGG | `[NOVO]` Testar antes de usar. | Só depois de confirmado. |
| Tipos de tabela e TVP | Proibido por convenção da SigmaCode. | Usar XML. |

Como confirmar: numa base de TESTE em nível 100, correr estes blocos de leitura, um de cada vez. Um erro de sintaxe ou "Invalid object name" quer dizer que a função está bloqueada nesse nível. Depois, passar a linha da tabela de "testar antes de usar" para "verificado em `<data>`, base `<nome>`". Se a base de testes não estiver em nível 100, o resultado não prova nada.

```sql
SELECT compatibility_level FROM sys.databases WHERE name = DB_NAME();
GO
SELECT TRY_CONVERT(int, '1') AS r;
GO
SELECT IIF(1 = 1, 'a', 'b') AS r;
GO
SELECT CONCAT('a', 'b') AS r;
GO
SELECT FORMAT(1234, 'N0') AS r;
GO
SELECT x FROM (VALUES (1), (2)) AS t(x) ORDER BY x OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;
GO
SELECT JSON_VALUE('{"a":1}', '$.a') AS r;
GO
SELECT ISJSON('{}') AS r;
GO
SELECT STRING_AGG(x, ',') AS r FROM (VALUES ('a'), ('b')) AS t(x);
GO
SELECT value FROM STRING_SPLIT('a,b', ',');
GO
SELECT [key], value FROM OPENJSON('{"a":1}');
GO
BEGIN TRY SELECT 1/0; END TRY BEGIN CATCH THROW; END CATCH;
GO
```

## 6. Objetos de base de dados

Fonte única da regra do que o Claude Code pode criar: Parte 1. Resumo: SPs, views e triggers novos, só em base de teste e com confirmação; nunca tabelas nem campos; índices, funções e tipos só com autorização explícita.

A tua v1 dizia "apenas é permitido criar Stored Procedures; não é permitido criar ou alterar índices, tabelas, colunas, views, funções, triggers ou tipos". Passa a: SPs, views e triggers novos permitidos (com as condições da Parte 1); tabelas e campos nunca (especificam-se para criares no PHC); índices, funções e tipos continuam a exigir autorização. Era uma regra de processo para o agente. `[CONFIRMAR]` com que permissões liga a conta SQL do Claude Code à base de testes; o ideal é o mínimo necessário.

Nomes:

| Objeto | Nome |
|---|---|
| Stored Procedure | `sc_<Entidade><Acao>`, esquema `dbo` (ex.: `sc_Transferencia_Gravar`, `sc_Artigo_ObterStock`). Nunca o prefixo `sp`: o SQL Server procura primeiro na master. |
| View | `[NOVO]` proposta: `sc_v_<Nome>` |
| Trigger | `[NOVO]` proposta: `tr_sc_<Tabela>_<Acao>` |
| Tabela de utilizador | `u_<nome>`, criada no PHC pelo utilizador |

No Landeiro os nomes são `u_v_crm_*` (views), `up_crm_*` (SPs) e `tr_crm_*` (triggers). `[CONFIRMAR]` se ficam como exceção desse cliente ou se alinham com a convenção acima.

Listas como parâmetro: XML, lido com `.nodes()` e `.value()`. Sem TVP nem tipos de tabela.

## 7. Ambientes e bases de teste

- Base de testes: `DemoSigmaCode`. `[CONFIRMAR]` instância e nível de compatibilidade.
- Só se escreve em bases de teste, com confirmação, depois de `SELECT DB_NAME()`. Nunca em bases de clientes nem de produção.
- A base de demonstração de um cliente (por exemplo `LAND2_DEMO`, usada só para os testes do Landeiro) é uma base de teste desse cliente e não se usa noutros projetos.
- Validar a performance numa cópia restaurada da base do cliente, numa instância de teste. Nunca na base real. (A tua v1 dizia "validar a performance na base real", o que contradizia a regra de nunca executar scripts contra clientes ou produção.)
- Dados reais em testes: só os autorizados pelo cliente e, se possível, de uma cópia restaurada. Sem dados pessoais em logs nem em prompts. `[NOVO]`

## 8. Pontos a confirmar nesta parte

1. Instância e nível de compatibilidade da `DemoSigmaCode`.
2. Resultado do script de confirmação da secção 5 (JSON, THROW, TRY_CONVERT, IIF, CONCAT, FORMAT, OFFSET/FETCH) numa base em nível 100.
3. Nomes de views e triggers (proposta na secção 6) e se o Landeiro fica como exceção.
4. O que acontece aos objetos de terceiros quando o PHC é atualizado.
