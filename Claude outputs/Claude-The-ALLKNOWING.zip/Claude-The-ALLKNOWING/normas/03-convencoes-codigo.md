# Parte 3 — Convenções de código

Versão 2.1 · 13/10/2026 · Substitui a v1 (a tua) e a v2 reconstruída.
Estado: parte do teu original, com as correções e as regras novas aplicadas. Regras comuns a todos os prompts; cada prompt acrescenta só o que é específico do pedido. `[CONFIRMAR]` quer dizer que não tenho certeza e deves validar. `[NOVO]` quer dizer que foi acrescentado na v2 e deves aceitar ou apagar. Sem marca: vem do teu original.

## 1. Princípios

1. Código de produção, claro, fácil de manter e pensado para reutilização. Boas práticas: SOLID, separação de responsabilidades, injeção de dependências, async de ponta a ponta.
2. Se uma regra colidir com uma boa prática, assinalar e propor alternativa.
3. Correto primeiro, simples depois. Entre duas soluções corretas, a mais simples de desenvolver e de manter. `[NOVO]`
4. Seguir os padrões que já existem no repositório. Se o padrão existente e estas convenções divergirem, o Claude Code assinala e pergunta; não refatora por iniciativa própria. `[NOVO]`
5. Sem dependências novas sem justificação e aprovação. `[NOVO]`
6. Todo o código novo vem comentado, com uma explicação simples do que faz: cada classe, cada método, cada bloco não óbvio e cada objeto SQL. Comentários e explicações em português de Portugal.

## 2. API (.NET 8)

- API organizada por módulo, e dentro de cada módulo por Controllers, Services e Mappers (ex.: `Modules/Logistica/Controllers`).
- Controllers finos: validar a entrada, chamar o Service e devolver a resposta. Sem lógica de negócio nem acesso a dados.
- Services com a lógica, expostos por interface e registados por injeção de dependências.
- Ao mover controllers, as rotas (`[Route]`) não podem mudar.
- Os endpoints existentes mantêm o contrato JSON (nomes, tipos, códigos HTTP), salvo decisão registada em `<decisions>`. `[NOVO]`

Contratos com a APP:
- A APP MAUI não é alterada sem indicação explícita.
- Rotas, objetos de request e response e formato JSON mantêm-se.
- Objetos novos são DTOs, convertidos para os objetos atuais da APP em Mappers dedicados. A conversão é temporária e tem de ser fácil de remover.

## 3. sServices e sUtils (.NET Framework 4.8)

- Compatíveis com .NET Framework 4.8: C# 7.3, sem records, init, file-scoped namespaces, `Span<T>` ou APIs exclusivas de .NET Core ou .NET 8. Também sem `using` declarations, switch expressions, `??=`, intervalos e índices (`[..]`, `^1`) nem anotações de nulos. `[NOVO]`
- O .NET Framework 4.8 não tem host nem injeção de dependências por defeito. O Claude Code lê primeiro o código existente e segue o padrão que lá estiver (container ou composição manual, e o logging atual). Não introduz Microsoft.Extensions.DependencyInjection nem `ILogger<T>` sem aprovação. `[CONFIRMAR]` qual é o padrão atual de cada projeto.
- Antes de alterar qualquer pacote NuGet, faz-se um build de teste (conflitos de assemblies e binding redirects) e só depois se segue. `[NOVO]`

## 4. Biblioteca partilhada (`sigma-phc-dossiers`)

- Alvo netstandard2.0, para poder ser usada por .NET Framework 4.8, .NET 8 e projetos futuros. C# compatível com essa alvo (sem records, init, file-scoped namespaces, etc.). Se o projeto não estiver em netstandard2.0, assinalar e propor a alteração antes de escrever código.
- Acesso a dados com Dapper sobre Microsoft.Data.SqlClient 5.x (`CommandType.StoredProcedure`, mapeamento direto para os modelos, métodos async com `CancellationToken`).
- A API referencia a biblioteca por ProjectReference ao projeto em `C:\_SigmaRepos\sigma-phc-dossiers` (caminho relativo no `.csproj`). Mais tarde passa a pacote NuGet, por isso a biblioteca não pode depender de nada da API. Nunca copiar ficheiros entre repositórios.
- Uma alteração que toque na biblioteca e na API faz-se com o mesmo nome de branch nos dois repositórios (secção 11).
- Alterar a API pública da biblioteca (assinaturas, DTOs partilhados) tem impacto nos consumidores: o prompt lista quem a consome e os testes cobrem esses consumidores. `[NOVO]`
- A biblioteca usa Options e Logging.Abstractions, não implementações concretas, e não lê configuração diretamente (secção 7).

## 5. DTOs, Services, Mappers e boilerplate

DTOs:
- Toda a troca de dados entre camadas é feita com DTOs (request e response na API, resultados das SPs). Nunca expor modelos de dados nem objetos internos.
- DTOs simples, sem lógica, compatíveis com netstandard2.0 quando estão na biblioteca partilhada.
- Mappers dedicados e simples (métodos de conversão), sem lógica de negócio.
- Nomes: `<Entidade>Dto`, `<Entidade>Service` com `I<Entidade>Service`, `<Entidade>Mapper`. `[CONFIRMAR]` nomes em uso.

Boilerplate reutilizável:
- O que se repete é implementado uma vez e reutilizado: executor genérico de SPs (ligação, parâmetros, timeout, log, tempo, erros), helpers de XML para listas, extension methods de registo na DI (ex.: `services.AddSigmaPhcDossiers(...)`), base para Mappers e respostas, constantes com os nomes das SPs.
- Abstrair só o que já se repete ou vai claramente repetir-se. Sem camadas genéricas "para o futuro" (ex.: repositório genérico).

## 6. Erros e logs

- try/catch nos pontos críticos: escritas na base de dados, chamadas às SPs, serviços externos, conversões que afetem o resultado. Nunca apanhar exceções para as ignorar, nem envolver todo o código em try/catch.
- Cada catch regista em log com contexto (módulo, ação, identificadores como o número do documento), sem dados sensíveis (connection strings, passwords, dados pessoais).
- API (.NET 8) e biblioteca: `ILogger<T>` (em bibliotecas, Microsoft.Extensions.Logging.Abstractions). Registar em Information o início, o fim e o tempo das ações críticas. .NET Framework 4.8: o logging que já existe no projeto (`[CONFIRMAR]` qual). Não introduzir outro sem aprovação.
- Respostas de erro à APP sucintas, sem stack traces nem nomes de tabelas; o detalhe fica no log. Manter o formato de erro que a APP já espera; se não existir, assinalar e propor um.
- Erros não previstos tratados por handler global (middleware ou `IExceptionHandler`); se já existir, reutilizar.
- Níveis: Information para o fluxo normal, Warning para o que é recuperável, Error para falhas. `[NOVO]`

## 7. Configuração

- Nada fixo no código: connection strings, timeouts, níveis de log, tamanhos de página, URLs e valores que mudem entre ambientes ou clientes vêm do `appsettings.json` e do `appsettings.{Environment}.json`.
- Options pattern (`IOptions<T>`) com classes tipadas e validação no arranque (`ValidateDataAnnotations` e `ValidateOnStart`), para a API falhar logo se faltar configuração.
- Bibliotecas de classes não leem configuração diretamente: recebem as opções por injeção (Microsoft.Extensions.Options, que suporta netstandard2.0), para funcionarem com qualquer host (appsettings, web.config ou app.config).
- Manter a forma atual de escolher a base de dados do cliente; se estiver fixa no código, assinalar e propor a passagem para configuração.
- Nomes das SPs não são configuração: ficam em constantes centralizadas.
- Segredos fora do repositório: variável de ambiente, DPAPI ou o mecanismo já existente. Ficheiros com valores reais (`appsettings.*.json`) no `.gitignore`; no repositório só um `appsettings.Example.json` sem segredos. `[NOVO]`
- .NET Framework 4.8: `[CONFIRMAR]` ficheiro de configuração usado hoje (`App.config` ou `Web.config`). Segue o que existe.

## 8. Base de dados

### 8.1 Objetos e nomes

A regra de permissões está na Parte 1 (fonte única): o Claude Code cria SPs, views e triggers novos e nunca cria tabelas nem campos. Os nomes estão na Parte 2, secção 6.

### 8.2 Stored Procedures

- Uma SP por ação, esquema `dbo`, padrão `sc_<Entidade><Acao>` (ex.: `sc_Transferencia_Gravar`). Nunca o prefixo `sp` (o SQL Server procura primeiro na master).
- Uma SP só se justifica se reduzir idas à base de dados, eliminar queries redundantes ou mover lógica que pertence ao servidor. Não converter por converter.
- Compatível com o nível 100 (Parte 2, secção 5).
- Listas passadas como parâmetro XML (`.nodes()` e `.value()`), sem TVP.
- Sem índices novos: aproveitar os existentes e evitar padrões que os anulem (funções sobre colunas no `WHERE`, conversões implícitas, `LIKE '%...'`, `OR` entre colunas). Se fizer falta um índice, assinalar como recomendação, com o ganho esperado, e não o criar.
- Escritas com transação explícita, TRY/CATCH e rollback (THROW, ou RAISERROR se THROW não funcionar no nível 100). Nunca deixar documentos do PHC parcialmente gravados.
- Sem SQL dinâmico concatenado; se inevitável, `sp_executesql` com parâmetros.
- Um ficheiro `.sql` por SP, idempotente (`CREATE OR ALTER`), com cabeçalho (nome, descrição, parâmetros, data). Script de instalação que aplique todas as SPs a uma base de dados, para correr em cada cliente.
- `SET NOCOUNT ON`. `[NOVO]`
- Parâmetros com o mesmo tipo e tamanho das colunas, para evitar conversões implícitas que inutilizam índices. `[NOVO]`
- Devolver só as colunas que o DTO usa; nada de `SELECT *`. `[NOVO]`

### 8.3 Views

- Só leitura. Nome conforme Parte 2, secção 6.
- Colunas explícitas, com os tipos finais. Números concatenados com texto levam CAST explícito.
- Sem `ORDER BY` dentro da view.
- Evitar views que dependem de outras views: são mais difíceis de manter e de otimizar. `[NOVO]`

### 8.4 Triggers

Só se criam triggers novos. Nunca se alteram, desativam, apagam nem reordenam triggers existentes (incluindo encriptados) e nunca se usa `sp_settriggerorder`.

- Leves: no trigger só o mínimo, tipicamente um INSERT em lote. A lógica pesada fica numa SP ou no serviço.
- Seguros para várias linhas: trabalham sobre `inserted` e `deleted` como conjuntos e nunca assumem uma só linha.
- Comparam `inserted` com `deleted` para saber o que mudou, em vez de `UPDATE(coluna)`, que só diz que a coluna entrou no SET.
- Nunca bloqueiam a gravação no PHC. Num trigger, um erro não tratado desfaz a gravação do PHC e, mesmo apanhado por TRY/CATCH, pode deixar a transação inutilizável (`XACT_STATE() = -1`). Por isso o trigger faz só operações que não costumam falhar (um INSERT simples numa tabela sem restrições que possam falhar) e o TRY/CATCH é só uma segunda linha de defesa. `[CONFIRMAR]` como se regista uma falha do trigger sem bloquear (definir em cada prompt).
- `SET NOCOUNT ON`.
- Cada trigger novo tem um script de remoção (rollback) e um script de verificação de que está ativo.
- Antes de criar, ler os triggers existentes da tabela (Parte 2, secção 4, consulta 2) para não duplicar comportamento.

### 8.5 Tabelas e campos: especificação para criar no PHC

O Claude Code nunca cria tabelas nem campos. Quando são precisos, o prompt traz a especificação em `<phc_tables>` (formato na Parte 6) e o utilizador cria-os no PHC.

- Primeiro verifica-se se é mesmo preciso: uma view, uma SP ou estado guardado fora do PHC resolvem? Só se justifica uma tabela nova quando as alternativas mais simples não chegam.
- Antes de especificar, confirma-se se a edição e a versão do PHC deste cliente permitem criar tabelas de utilizador (no Advanced, segundo a indicação da equipa, não permitem). Se não permitem, o prompt traz uma alternativa sem tabela (estado guardado no serviço, marca de água pelos campos de auditoria do PHC, ou reutilização de uma tabela de utilizador existente), com prós e contras.
- Por tabela: nome (`u_<nome>`), finalidade, quem cria e onde. Por campo: nome, tipo, tamanho ou precisão, nulo, valor por defeito e regra ou domínio. Ainda: chave e relações, e índices propostos (a aprovar).
- O PHC traz os campos standard (stamp, auditoria, marcada). A especificação lista só os campos próprios; a estrutura final confirma-se com o script de verificação.
- O script de verificação (`01_verificar_<tabela>.sql`) só lê (`INFORMATION_SCHEMA` e `sys.*`) e falha com `RAISERROR` (severidade 16) e uma mensagem clara se faltar a tabela, um campo, um tipo ou um tamanho. Se falhar, o Claude Code pára a parte que depende da tabela, escreve "BLOQUEIO:" com a lista do que falta e continua o resto.

### 8.6 Compatibilidade SQL

SQL compatível com o nível de compatibilidade da base do cliente (por defeito 100). O estado de cada função e sintaxe está na Parte 2, secção 5. Um teste que passa numa base de nível superior (por exemplo `LAND2_DEMO`, em 150) não prova compatibilidade com o nível 100.

### 8.7 Verificação antes de instalar

Antes de pedir confirmação para instalar um lote de scripts, o Claude Code faz estas verificações. O pedido de confirmação é um por lote ou por módulo, com a lista de scripts e a base de destino; se o utilizador pedir confirmação por script, segue isso.

1. Pesquisa de texto em todos os scripts (por exemplo com `grep` ou `Select-String`). Não pode existir:
   - `CREATE TABLE`, exceto de tabelas temporárias (`#nome`);
   - `ALTER TABLE` (inclui `ENABLE TRIGGER` e `DISABLE TRIGGER`);
   - `DROP TABLE` e `TRUNCATE TABLE`;
   - `SELECT … INTO` que não seja para uma tabela temporária (`#nome`);
   - `sp_rename` sobre tabelas ou colunas, e `sp_settriggerorder`;
   - `DROP TRIGGER`, `ALTER TRIGGER` ou `CREATE OR ALTER TRIGGER` sobre triggers que não sejam novos e nossos;
   - `CREATE INDEX`, `CREATE FUNCTION`, `CREATE TYPE`, `CREATE SEQUENCE`, `CREATE ROLE` e `CREATE LOGIN`, salvo autorização explícita registada em `<decisions>`.
2. Cada script de instalação começa com uma guarda de base de dados, que impede a execução fora das bases de teste autorizadas `[NOVO]`:

```sql
-- Guarda: só deixa correr nas bases de teste autorizadas.
DECLARE @bd sysname = DB_NAME();
IF @bd NOT IN (N'DemoSigmaCode')   -- acrescentar aqui só bases de TESTE
BEGIN
    RAISERROR(N'Base de dados nao autorizada: %s', 16, 1, @bd);
    SET NOEXEC ON;   -- o resto do script nao executa
END
GO
-- ... objetos do script ...
SET NOEXEC OFF;   -- no fim, repoe a execucao normal
GO
```

3. Cada objeto novo tem script de remoção (rollback) que só apaga objetos nossos.
4. Os scripts são reinstaláveis (podem correr duas vezes sem erro).
5. Nenhum script contém passwords, tokens nem connection strings.

## 9. Testes

- Cada alteração leva testes apropriados, com os cenários listados no prompt. Se a lista faltar, o Claude Code propõe-na no PLANO antes de implementar.
- Validar sempre que os resultados novos são iguais aos atuais e medir antes e depois (método na Parte 7, tag `<tests>`).
- .NET: o framework de testes que o repositório já usa. `[CONFIRMAR]` qual (xUnit, NUnit ou MSTest). Se não houver testes, propõe e pede aprovação, porque é uma dependência nova.
- SQL: scripts de teste com verificações (asserts) que falham com mensagem clara, corridos só na base de testes.
- Triggers: testar uma linha, várias linhas, uma alteração que não muda nada (não deve gerar registo) e que a gravação no PHC não falha. `[NOVO]`
- Os testes não usam dados reais de clientes nem credenciais reais; usam dados fictícios.
- O plano de testes, as evidências e a documentação mínima estão definidos na task `testes-documentacao` (Parte 4). `[NOVO]`
- Quando um teste não pode ser corrido (sem base de testes, sem rede), o Claude Code diz-o em TESTES e explica o que ficou por validar. Não declara como testado o que não correu. `[NOVO]`

## 10. Segurança

- Nunca incluir passwords, tokens ou connection strings em prompts, código, logs, testes ou documentação. Referenciar pela configuração (appsettings, DPAPI ou variável de ambiente).
- Credencial partilhada no chat: assinalar que deve ser trocada.
- Consultas parametrizadas. Nunca construir SQL por concatenação de texto que venha de fora.
- Utilizadores SQL e contas de serviço com o mínimo de permissões necessárias. `[NOVO]`
- Validar entradas externas (DTOs, ficheiros, respostas de APIs de terceiros). `[NOVO]`
- Nunca executar scripts contra bases de dados de clientes ou de produção. Na DemoSigmaCode, só com confirmação prévia e depois de confirmar o nome da base com `SELECT DB_NAME()`.
- Integração com APIs de terceiros: HTTPS sempre que possível; se só houver HTTP, registar o risco em RISCOS. `[NOVO]`

## 11. Forma de trabalho e git

- Ler o código existente antes de propor alterações.
- Análise primeiro, código depois de aprovação. Em trabalhos por módulo, trabalhar módulo a módulo e ação a ação, com aprovação antes de implementar e antes de avançar (modo Plan Mode da task; ver Parte 1).
- Na falta de informação, perguntar em vez de assumir.
- Branch próprio em cada repositório alterado; sem commit nem push sem confirmação do utilizador.
- O mesmo nome de branch em todos os repositórios alterados na mesma tarefa (por exemplo `feature/logistica-transferencias`), porque a API referencia a biblioteca por ProjectReference.
- Mudanças estruturais (reorganizar, mover, renomear) e mudanças de comportamento em commits separados, de preferência em branches separados. `[NOVO]`
- Nunca fazer commit de credenciais, de ficheiros de configuração com valores reais, de `bin/` e `obj/`, de logs, nem da pasta `Claude outputs/`. O `.gitignore` cobre-os antes do primeiro commit. `[NOVO]`
- Antes de qualquer push, ver os ficheiros que vão (`git status` e `git diff`) e confirmar que o repositório de destino é privado. `[NOVO]`
- A pasta `docs/tasks/` (prompts das tasks e `00-global.md`) é versionada com o código: é o histórico do trabalho. `[NOVO]`

## 12. Revisão crítica antes de entregar

O Claude Code relê a própria implementação e responde, em REVISÃO:

1. Cumpre o que o prompt pede e nada mais (âmbito e "Fora de âmbito")?
2. É a solução mais simples que é correta? O que se podia apagar?
3. Segue os padrões que já existem?
4. Há credenciais, caminhos ou nomes de clientes no código ou nos logs?
5. O que acontece com entrada vazia, nula, muito grande ou repetida? E com falha de rede ou da base?
6. Os testes cobrem os cenários listados? Algum falharia se o código estivesse errado?
7. Riscos e impactos para RISCOS: o que pode correr mal, em que ambiente e como se desfaz.

## 13. Pontos a confirmar nesta parte

1. Padrão de injeção de dependências ou composição manual, e de logging, em sServices e sUtils.
2. Ficheiro de configuração usado no .NET Framework 4.8.
3. Framework de testes (xUnit, NUnit ou MSTest).
4. Nomes de DTOs, Services e Mappers em uso.
