# Parte 8 — Dicionário de dados do PHC

Versão 2.0 · 13/10/2026 · Substitui a v1.0.
Estado: reduzido a partir do `Livro1.xlsx`. `[CONFIRMAR]` quer dizer que não tenho certeza e deves validar.

## 1. O que há e onde está

- Neste ficheiro: as convenções que valem para todas as tabelas (secção 2), o essencial de 25 tabelas (secção 4) e o diretório das tabelas relevantes (secção 5). É só o necessário para escrever bons prompts.
- No repositório `Claude-The-ALLKNOWING`, em `docs/phc/`: `phc-dicionario.txt` (13 986 campos de 565 tabelas, uma secção por tabela) e `gerar-dicionario.py`. Só o Claude Code os consulta, por `sc-leitor`; não se carregam no Projeto. O Excel só é preciso para gerar de novo (secção 7).
- O livro original tem 885 tabelas e 107 840 linhas, mas só 25 442 campos únicos. Ficaram 13 986 (secção 6).
- `[CONFIRMAR]` de que versão e edição do PHC vem o livro; o ficheiro não o diz. Antes de o usar num cliente, o assistente pergunta qual é a versão do cliente e avisa se for diferente.

## 2. Convenções do PHC (valem para todas as tabelas; por isso não se repetem em cada uma)

1. Chave: `<tabela>STAMP`, `char(25)`, gerada pela aplicação (`CLSTAMP`, `BOSTAMP`, `FTSTAMP`, `FISTAMP`, `STSTAMP`). O dicionário não a lista; `[CONFIRMAR]` na base. Nas linhas, o stamp do cabeçalho aparece como campo de ligação (`BI.BOSTAMP`, `FI.FTSTAMP`, `FN.FOSTAMP`).
2. Campos de auditoria em quase todas as tabelas: `OUSRINIS`, `OUSRDATA`, `OUSRHORA`, `USRINIS`, `USRDATA`, `USRHORA` e `MARCADA`. Não estão listados abaixo. `[CONFIRMAR]` os tipos na base.
3. Valores monetários: o campo com prefixo `E` é em euros (`N19.6`) e o campo sem `E` é o legado em escudos (PTE, `N18.5`). Usar sempre o campo em euros. Evidência: `FT.TOTAL` é "Total do Documento em PTE" e `FT.ETOTAL` é "Total do Documento". Só se aplica quando existem os dois campos com esses tamanhos (por exemplo, `ESTAB` não é um campo em euros). Nas listas abaixo, o legado vem indicado em `[legado PTE: ...]`.
4. Campos derivados de datas (prefixos `D_`, `M_`, `S_`, `T_`, `A_` e `M_ALFA_` mais o nome de um campo data) são partes da data: ignorar.
5. Tipos do PHC: C (texto, com comprimento), N (número, com comprimento e casas decimais), L (lógico), D (data), M (memo). O dicionário escreve-os assim: `C55`, `N10`, `N19.6`, `L`, `D`, `M`. A correspondência com o SQL Server (por exemplo C para `varchar(n)` ou `char(n)`, L para `bit`, D para `datetime`, M para `text` ou `varchar(max)`) é uma suposição `[CONFIRMAR]`: o tipo real lê-se da base (secção 3, passo 4).
6. Campos de utilizador começam por `u_`; tabelas de utilizador também. Não existem neste dicionário.

## 3. Como o assistente o usa

1. Antes de propor uma tabela ou um campo novo, procura aqui se o PHC já tem o que é preciso. Se tem, usa-o e diz qual. Só propõe `u_` quando não há equivalente.
2. Escreve nomes, tipos e tamanhos como estão na secção 4. Se precisares de um campo que não está na secção 4, não o inventes: pede ao Claude Code (`sc-leitor`) que o procure em `docs/phc/phc-dicionario.txt`, pesquisando `^## CL ` com 80 linhas de contexto (o espaço final distingue `CL` de `CL2`).
3. Num prompt para o Claude Code, que não vê este projeto, põe em `<phc_tables>` ou `<context>` só o extrato das tabelas e campos usados, ou indica o caminho `docs/phc/phc-dicionario.txt` e o padrão de pesquisa. Nunca coles o dicionário inteiro.
4. Pede sempre que o `sc-leitor-bd` confirme o tipo real na base de testes, por exemplo com a consulta `SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'cl' ORDER BY ORDINAL_POSITION` (uma tabela de cada vez).

## 4. Essencial por tabela

Escolhido à mão: identificação, morada, contactos, classificação, valores, ligações entre tabelas e o que é usado em integrações. Cada campo existe no dicionário, com o tipo e a descrição do PHC. O número entre parênteses é o de campos úteis que a tabela tem no dicionário completo.

### CL — Clientes (53 de 225 campos úteis)
```text
NO N10 Número do Cliente
ESTAB N3 Estabelecimento
NOME C55 Nome do Cliente
NOME2 C55 Abreviatura do Nome
NCONT C20 Nº Contribuinte
MORADA C55 Morada
LOCAL C43 Localidade
CODPOST C45 Código Postal
DISTRITO C20 Distrito
CODPAIS C2 Código do País da morada
PAIS N1 País de Origem
TELEFONE C60 Telefone
TLMVL C45 Telemóvel
FAX C60 Fax
EMAIL C100 E-mail
SITE C20 Loja
CONTACTO C30 Nome do 1º Contacto
TIPO C20 Tipo de Cliente
TIPODESC C20 Tipo de Cliente para Descontos
VENDEDOR N4 Nº de Vendedor
VENDNM C20 Nome do Vendedor
ZONA C20 Zona do Cliente
SEGMENTO C25 Segmento de Mercado
MOEDA C11 Moeda habitual
TABIVA N1 Tabela de IVA fixa
DESCONTO N5.2 Desconto Habitual
DESCPP N5.2 Desconto Financeiro
PAGAMENTO C28 Modo de Pagamento
CCUSTO C20 Centro Analítico
NCUSTO C20 Natureza
CONTA C15 Conta na Contabilidade
INACTIVO L Inativo ?
NOCREDIT L Faturação cancelada ?
EPLAFOND N19.6 Plafond de Crédito [legado PTE: PLAFOND]
ESALDO N19.6 Saldo [legado PTE: SALDO]
ALIMITE N5 Limite de Crédito
OBS C240 Observações
OBSDOC M Observações para Documentos Eletrónicos
IBAN C40 Número internacional de conta bancária (IBAN)
BIC C20 Código de identificação do banco (BIC)
NIB C28 NIB
REFCLI C12 Código de referência
CODFORNECEDOR C10 Nº de fornecedor no cliente
GLNCL C35 Código GLN do cliente
EANCL C35 Código EAN do cliente
CLASSE C100 Classificação dos documentos de faturação
ROTA C20 Rota de cobrança
PNCONT C2 Iniciais do País de origem
LANG C20 Idioma
CODMOTISEIMP C3 Código Motivo de Isenção de Imposto
MOTISEIMP C120 Motivo de Isenção de Imposto
FLNO N10 Número de fornecedor
FLESTAB N3 Estabelecimento de fornecedor
```
### CL2 — Clientes - Outros Dados (13 de 56 campos úteis)
```text
CODPAIS C2 Código do País
DESCPAIS C55 País da morada
TIPOPESSOA N1 Tipo de pessoa. Física ou Jurídica
ENTPUBLICA L É Entidade Pública ?
EMAILDOC C100 Email para envio documentos eletrónicos
DOCELETRONICOS L Tem acesso à Documentos Eletrónicos extranet web ?
COMUNICADOCELETRON C20 Comunica documentos eletrónicos com webservices
NIFVALIDADO L NIF validado ?
LATITUDE N10.6 Latitude
LONGITUDE N10.6 Longitude
ISB2B L Indica se a autorização de débito direto é para o sistema SEPA B2B ?
NOMEAT C254 Nome associado ao NIF no portal da DNRE
CODENDERECO C20 e-Fatura: Código do Endereço
```
### FL — Fornecedores (40 de 145 campos úteis)
```text
NO N10 Número
ESTAB N3 Estabelecimento
NOME C55 Nome
NOME2 C55 Abreviatura do Nome
NCONT C20 Nº Contribuinte
MORADA C55 Morada
LOCAL C43 Localidade
CODPOST C45 Cód. Postal
DISTRITO C50 Distrito
PAIS N1 País de Origem
TELEFONE C60 Telefone
TLMVL C45 Telemóvel
FAX C60 Fax
EMAIL C100 eMail
SITE C20 Loja
CONTACTO C30 Tratamento do 1º Contacto
TIPO C20 Tipo de Fornecedor
MOEDA C11 Moeda
TABIVA N2 Tabela de IVA
DESCONTO N5.2 Desconto Habitual
DESCPP N5.2 Desc. PP
PAGAMENTO C22 Pagamento
CCUSTO C20 Centro Analítico
NCUSTO C20 Natureza
CONTA C15 Conta na Contabilidade
INACTIVO L Inativo ?
NOCREDIT L Compras Canceladas ?
PLAFOND N16.3 Plafond
ESALDO N19.6 Saldo [legado PTE: SALDO]
OBS C240 Observações
IBAN C40 Número internacional de conta bancária (IBAN)
BIC C20 Código de identificação do banco (BIC)
NIB C28 NIB
FREF C20 Centro de Gastos
CAE C5 Código CAE
ZONA C20 Zona
PNCONT C2 Iniciais do País de origem
LANG C20 Idioma
CLNO N10 Número de Cliente
CLESTAB N3 Estabelecimento de Cliente
```
### ST — Stocks e Serviços (38 de 170 campos úteis)
```text
REF C18 Referência
DESIGN C60 Designação
CODIGO C40 Código de Barras
FAMILIA C18 Família
FAMINOME C60 Designação da Família
STOCK N13.3 Stock total atual
STMIN N13.3 Stock Mínimo
STMAX N13.3 Stock Máximo
PTOENC N10.3 Ponto de Encomenda
EPV1 N19.6 Euros: Preço Venda 1 [legado PTE: PV1]
EPV2 N19.6 Euros: Preço Venda 2 [legado PTE: PV2]
EPV3 N19.6 Euros: Preço Venda 3 [legado PTE: PV3]
EPV4 N19.6 Euros: Preço Venda 4 [legado PTE: PV4]
EPV5 N19.6 Euros: Preço Venda 5 [legado PTE: PV5]
EPCUSTO N19.6 Euros: Preço Custo [legado PTE: PCUSTO]
EPCPOND N19.6 Euros: Preço Custo Ponderado [legado PTE: PCPOND]
EPCULT N19.6 Euros: Último Custo [legado PTE: PCULT]
TABIVA N1 Tabela de IVA
IVA1INCL L IVA Incluído no Preço de Venda 1 ?
IVA2INCL L IVA Incluído no Preço de Venda 2 ?
IVA3INCL L IVA Incluído no Preço de Venda 3 ?
IVA4INCL L IVA Incluído no Preço de Venda 4 ?
IVA5INCL L IVA Incluído no Preço de Venda 5 ?
INACTIVO L Inativo ?
BLOQUEADO L Bloqueado ?
FORNEC N10 Número de Fornecedor
FORNECEDOR C55 Fornecedor
FORNESTAB N3 Estabelecimento de Fornecedor
FORREF C20 Refª Fornecedor
PESO N14.3 Peso Líquido
VOLUME N11.3 Volume
LOCAL C20 Localização
NOSERIE L Número de Série ?
QTTCLI N13.3 Encomendas Clientes
QTTFOR N13.3 Encomendas Fornecedores
QTTREC N13.3 Quantidade em receção
OBS C68 Observações
CODFISCAL C20 Código Fiscal
```
### SA — Stock por Armazém (12 de 17 campos úteis)
```text
REF C18 Referência
ARMAZEM N5 Armazém
STDESIGN C60 Designação
STOCK N13.3 Stock
STMIN N15.3 Stock Mínimo
PTOENC N15.3 Ponto de Encomenda
EPCPOND N19.6 Euros: Preço Custo Ponderado [legado PTE: PCPOND]
EPV N19.6 Euros: Preço de Venda [legado PTE: PV]
RESCLI N15.3 Encomendado por Clientes
RESFOR N15.3 Encomendado a Fornecedores
QTTACIN N15.3 Quantidade Entrada Acumulada
QTTREC N15.3 Quantidade em receção
```
### SL — Movimentos de Stock (27 de 62 campos úteis)
```text
REF C18 Referência do Artigo
DESIGN C60 Designação
CM N6 Cod.Documento
CMDESC C20 Descrição do Código de Movimento
ARMAZEM N5 Armazém
DATALC D Data Movimento
HORA C8 Hora do Movimento
ADOC C50 Nº Documento
LOTE C30 Lote
QTT N12.3 Quantidade
EVU N19.6 Euros: Preço Unitário [legado PTE: VU]
ETT N19.6 Euros: Total [legado PTE: TT]
ORIGEM C2 Origem do movimento
STOCKTOT N13.3 Stock Total
STOCKARM N13.3 Stock Total por Armazém
FRCL N10 NºEmpresa
FREF C20 Centro de Gastos
NOME C55 Nome
CCUSTO C20 Centro Analítico
MOEDA C11 Moeda Est.
SEGMENTO C25 Segmento de Mercado
ZONA C30 Descrição da Zona do armazém
IDENTIFICACAO C55 Identificação do Alvéolo
LNO N6 Nº Mov.
FISTAMP C25 Ligação ao Ficheiro FI
FNSTAMP C25 Ligação ao Ficheiro FN
BISTAMP C25 Ligação ao Ficheiro BI
```
### STFAMI — Famílias de Artigos (9 de 60 campos úteis)
```text
REF C18 Referência
NOME C60 Nome da Família
TABIVA N1 Tabela de IVA
FORNEC N10 Número de Fornecedor
FORNECEDOR C55 Fornecedor
NOSERIE L Número de Série ?
LOTES L Utiliza Lotes ?
TIPOPROD C1 Tipo para inventário - AT
CONVERSAO N15.7 Fator Conversão
```
### BO — Dossiers Internos (37 de 191 campos úteis)
```text
NMDOS C24 Nome Dossier
NDOS N3 Nº Interno do Dossier
OBRANO N10 Número do Dossier
BOANO N4 Ano do dossier
BOID N12 Número sequencial interno
DATAOBRA D Data do dossier
DATAFECHO D Data de fecho
FECHADA L Fechado ?
NO N10 Número
ESTAB N3 Estabelecimento
NOME C55 Nome
NOME2 C55 Abreviatura do Nome
NCONT C20 Nº Contribuinte
MORADA C55 Morada
LOCAL C43 Localidade
CODPOST C45 Cod. Postal
ETOTAL N19.6 Total [legado PTE: TOTAL]
ETOTALDEB N19.6 Total (Compra) [legado PTE: TOTALDEB]
MOEDA C11 Moeda
MOETOTAL N13.3 Moeda estrangeira: Total
VENDEDOR N4 Número
VENDNM C20 Nome
ZONA C20 Zona
SEGMENTO C25 Segmento de Mercado
CCUSTO C20 Centro Analítico
NCUSTO C20 Natureza
OBS C67 Observações
TABELA1 C20 Pedido Por:
TABELA2 C25 Destino
TIPO C20 Tipo de Cliente
SERIE C50 Destino Mercad.
SITUACAO N1 Situação da Obra
SITE C20 Loja
ORIGEM C25 Origem do dossier
PNO N3 Nº interno do Terminal de Vendas
PNOME C20 Nome do Terminal de Vendas
HORAEMISSAO C10 Hora de Emissão do documento
```
### BO2 — Dossiers Internos - Outros Dados (17 de 138 campos úteis)
```text
ANULADO L Documento ANULADO ?
ARMAZEM N5 Número de Armazém
CONTACTO C50 Contacto da morada de entrega
EMAIL C100 Email da morada de entrega
TELEFONE C60 Telefone da morada de entrega
MORADA C55 Morada de entrega
LOCAL C43 Localidade da morada de entrega
CODPOST C45 Código Postal da morada de entrega
XPDDATA D Data de expedição
XPDHORA C5 Hora de expedição
ETOTALCIVA N19.6 Total com IVA [legado PTE: TOTALCIVA]
TOTIVA N19.6 Total de IVA
IDENTIFICACAO1 C55 Identificação do Alvéolo
IDENTIFICACAO2 C55 Identificação do Alvéolo de destino
CAMBIO N16.6 Câmbio usado se fixo
PROCESSO C20 Processo
TIPOSAFT C2 Tipo de documento para SAF-T
```
### BI — Linhas de Dossiers Internos (43 de 159 campos úteis)
```text
BOSTAMP C25 Ligação ao Ficheiro BO
NMDOS C24 Nome do Dossier
NDOS N3 Número Interno do Dossier
OBRANO N10 Número do Dossier
LORDEM N10 Ordem da linha
REF C18 Referência
DESIGN C60 Designação
CODIGO C40 Código de Barras
FAMILIA C18 Familia do artigo
ARMAZEM N5 Número de Armazém
QTT N14.4 Quant.
QTT2 N14.4 Recepcionado
EPU N19.6 Preço [legado PTE: PU]
EDEBITO N19.6 Compra [legado PTE: DEBITO]
ETTDEB N19.6 Total Compra [legado PTE: TTDEB]
DESCONTO N6.2 Desconto
DESC2 N5.2 Desconto 2
DESC3 N5.2 Desconto 3
DESC4 N5.2 Desconto 4
DESC5 N5.2 Desconto 5
DESC6 N5.2 Desconto 6
IVA N5.2 Taxa de IVA
TABIVA N1 Tabela de IVA
IVAINCL L IVA Incluído ?
DATAOBRA D Data do dossier
FDATA D Data do documento que movimentou
LOTE C30 Lote
NOSERIE L O artigo tem nº série ?
NO N10 Nº Fornecedor
ESTAB N3 Estabelecimento
NOME C55 Nome
CCUSTO C20 Centro Analítico
NCUSTO C20 Natureza
LOBS C40 Obs
PESO N14.3 Peso
VOLUME N11.3 Volume
OBISTAMP C25 Ligação ao Ficheiro BI
OOBISTAMP C25 Ligação ao Ficheiro Origem BI
OOBOSTAMP C25 Stamp do BO de onde a linha foi copiada
OFOSTAMP C25 Ligação ao Ficheiro FO
OFTSTAMP C25 Ligação ao Ficheiro FT
ORISTAMP C25 Ligação da Referência/Tarefa
FECHADA L Fechado ?
```
### FT — Documentos de Faturação (35 de 317 campos úteis)
```text
NMDOC C20 Nome do Documento
NDOC N3 Número interno do Documento
FNO N10 Número do Documento
FTANO N4 Ano do documento
FDATA D Data do documento
PDATA D Data de vencimento
TAXPOINTDT D Data efetiva de entrega dos bens ou da prestação do serviço ao cliente
NO N10 Número do Cliente
ESTAB N3 Estabelecimento do Cliente
NOME C55 Nome do Cliente
NOME2 C55 Abreviatura do Nome
NCONT C20 Nº Contribuinte do Cliente
MORADA C55 Morada do Cliente
LOCAL C43 Localidade do Cliente
CODPOST C45 Código Postal do Cliente
PAIS N1 País de origem do cliente
ETOTAL N19.6 Total do Documento [legado PTE: TOTAL]
ETTILIQ N19.6 Total ilíquido [legado PTE: TTILIQ]
ETTIVA N19.6 Total de IVA [legado PTE: TTIVA]
MOEDA C11 Moeda
CAMBIO N16.6 Câmbio usado se fixo
VENDEDOR N4 Nº de Vendedor
VENDNM C20 Nome do Vendedor
ZONA C20 Zona
SEGMENTO C25 Segmento de mercado
TIPODOC N1 Tipo Interno de Documento
TIPO C20 Tipo de cliente
ANULADO L Documento ANULADO ?
PAGAMENTO C28 Pagamento
CCUSTO C20 Centro Analítico
NCUSTO C20 Natureza
HORAEMISSAO C10 Hora de Emissão do documento
SERIES M Nºs de série do documento
FTID N12 Número sequencial interno
MATRICULA C12 Matrícula da Viatura
```
### FI — Linhas de Documentos de Faturação (35 de 185 campos úteis)
```text
FTSTAMP C25 Campo de ligação ao FT
NMDOC C20 Nome do Documento
NDOC N3 Número interno do documento
FNO N10 Número do Documento
FTANOFT N4 Ano do documento que facturou
REF C18 Referência do Artigo
DESIGN C60 Designação
CODIGO C40 Código de Barras
FAMILIA C18 Familia do artigo
ARMAZEM N5 Armazém
QTT N12.3 Quantidade
EPV N19.6 Preço Unitário [legado PTE: PV]
DESCONTO N6.2 Desconto 1
DESC2 N5.2 Desconto 2
DESC3 N5.2 Desconto 3
DESC4 N5.2 Desconto 4
DESC5 N5.2 Desconto 5
DESC6 N5.2 Desconto 6
IVA N5.2 Taxa de IVA
TABIVA N1 Tabela de IVA
IVAINCL L Têm IVA incluido ?
ETILIQUIDO N19.6 Total [legado PTE: TILIQUIDO]
LOTE C30 Lote
COMPOSTO L Composto ?
LORDEM N10 LORDEM
BISTAMP C25 Ligação a dossiers internos
OFISTAMP C25 Campo de ligação ao FI
OFTSTAMP C25 Campo de ligação ao FT
OREF C18 Refª do artigo ou serviço (se origem já movimentou)
CPOC N6 Código CSNC
FICCUSTO C20 Centro Analítico
CODMOTISEIMP C3 Código Motivo de Isenção de Imposto
MOTISEIMP C120 Motivo de Isenção de Imposto da linha
TAXPOINTDT D Data efetiva de entrega dos bens ou da prestação do serviço ao cliente
ECUSTO N19.6 Custo Unitário [legado PTE: CUSTO]
```
### TD — Configuração de Documentos de Faturação (19 de 192 campos úteis)
```text
NMDOC C20 Nome do documento no Singular
NDOC N3 Número interno do documento
TIPODOC N1 Tipo interno de documento
TIPOSAFT C2 Tipo de documento para SAF-T
ACTIVO L Permite indicar se é um ativo nas linhas ?
ARMAZEM N5 Armazém por defeito
FECHADA L Série de documentos de faturação fechada ?
CMSL N5 Número do Código de Movimento nos Stocks
CMSLN C20 Código de Movimento nos Stocks
CMCC N5 Número do Código de Movimento nas Contas Correntes
CMMCC N5 NºCódigo de Movimento nas C/c de multipagamento
LANCASL L Lança em stocks ?
LANCACC L Lança em conta corrente ?
LANCACLI L Lança movimentos no 2º cliente ?
AUTOFAT L É um documento de autofaturação ?
GUIAREMESSA L Guia de Remessa a ser faturada ?
RASCUNHO L Permite documentos em rascunho ?
EXCLUISAFT L Excluir do SAF-T ?
TEMSERIE L Pode ter equipamentos agregados ao documento ?
```
### TS — Configuração de Dossiers Internos (11 de 201 campos úteis)
```text
NMDOS C24 Nome do Dossier no Singular
NDOS N3 Nº Dossier
TIPODOS C15 Tipo de Dossier
TIPOSAFT C2 Tipo de documento para SAF-T
ARMAZEM N5 Armazém por defeito
CMSTOCKS N2 Código do movimento 1
CMDESC C20 Descrição do movimento 1
CM2STOCKS N2 Código do movimento 2
CM2DESC C20 Descrição do movimento 2
STOCKS L Movimenta stocks ?
CAMBIO N1 Câmbio nas Vendas ou nas compras
```
### CC — C/Correntes Clientes e Entidades (22 de 122 campos úteis)
```text
NO N10 Número do Cliente
ESTAB N3 Número de Estabelecimento
NOME C55 Nome do Cliente
CM N6 Código do movimento
CMDESC C20 Descrição do movimento
DATALC D Data do movimento
DATAVEN D Data de Vencimento
CCNDOC N3 Nº da série do Documento
CCNMDOC C20 Nome da série do Documento
FTFNO N10 Número da Fatura
FTNDOC N3 Número do Documento de Faturação
EDEB N19.6 Euros: Débito [legado PTE: DEB]
ECRED N19.6 Euros: Crédito [legado PTE: CRED]
EDEBF N19.6 Euros: Débito já regularizado [legado PTE: DEBF]
ECREDF N19.6 Euros: Crédito já regularizado [legado PTE: CREDF]
ESALDO N18.5 Saldo (Débito-Crédito)
MOEDA C11 Moeda do movimento
ORIGEM C8 Origem do movimento
FTSTAMP C25 Ligação ao ficheiro FT
RESTAMP C25 Ligação ao ficheiro RE
OBS C250 Observações
VENDEDOR N4 Nº de Vendedor
```
### FO — Compras a Fornecedores (26 de 213 campos úteis)
```text
DOCNOME C20 Documento
ADOC C50 Nº Documento
DOCDATA D Data Original do documento
DATA D Data Interna
PDATA D Data de Vencimento
NO N10 Número
ESTAB N3 Estabelecimento
NOME C55 Nome do Fornecedor
NOME2 C55 Abreviatura do Nome
NCONT C20 Nº Contribuinte do Fornecedor
MORADA C55 Morada do Fornecedor
LOCAL C43 Localidade do Fornecedor
CODPOST C45 Cód. Postal do Fornecedor
PAIS N1 País de Origem
ETOTAL N19.6 Total [legado PTE: TOTAL]
ETTILIQ N19.6 Total Ilíquido [legado PTE: TTILIQ]
ETTIVA N19.6 Total IVA [legado PTE: TTIVA]
MOEDA C11 Moeda estrangeira
CAMBIO N20.10 Câmbio usado se fixo
FOANO N4 Ano do documento
FOID N12 Número sequencial interno
CCUSTO C20 Centro Analítico
NCUSTO C20 Natureza
TIPO C20 Tipo de Fornecedor
FREF C20 Centro de Gastos
PROCESSO C20 Processo
```
### FN — Linhas de Compras a Fornecedores (27 de 112 campos úteis)
```text
FOSTAMP C25 Ligação ao ficheiro FO
DOCNOME C20 Documento
ADOC C50 Nº Documento
DATA D Data
REF C18 Referência
DESIGN C80 Designação
CODIGO C40 Código de Barras
FAMILIA C18 Familia do artigo
ARMAZEM N5 Armazém
QTT N12.3 Quantidade
EPV N19.6 Preço Unitário [legado PTE: PV]
DESCONTO N5.2 Desconto 1
DESC2 N5.2 Desconto 2
DESC3 N5.2 Desconto 3
DESC4 N5.2 Desconto 4
DESC5 N5.2 Desconto 5
DESC6 N5.2 Desconto 6
IVA N5.2 IVA
TABIVA N1 Tabela IVA
IVAINCL L IVA Incluído ?
ETILIQUIDO N19.6 Total Ilíquido [legado PTE: TILIQUIDO]
LOTE C30 Lote
BISTAMP C25 Ligação ao ficheiro BI
OFNSTAMP C25 Ligação ao ficheiro FN-Origem
OREF C18 Refª do artigo ou serviço (se origem já movimentou)
FNCCUSTO C20 Centro Analítico da linha
QTTRCB N14.4 Quantidade Recebida
```
### TAXASIVA — Taxas de IVA (4 de 4 campos úteis)
```text
CODIGO N1 Tabela de IVA
TAXA N5.2 Taxa de IVA
REF C18 Referência
DESIGN C60 Designação
```
### CM2 — Códigos de movimentos de stocks (6 de 6 campos úteis)
```text
CMDESC C20 Descrição do movimento
CM N6 Código do movimento
MUDAPCPOND L Afeta o Preço de Custo Ponderado (Só para entradas) ?
MUDAPCULT L Afeta o Último Preço de Custo (Só para entradas) ?
OBRIGACPSL L Obriga a ter código de interligação de stocks relacionado ?
ENTRADA L Movimento de entrada de stocks ?
```
### CM3 — Vendedores (25 de 25 campos úteis)
```text
CMDESC C20 Nome abreviado do Vendedor
CM N4 Nº de Vendedor
NOME C40 Nome Completo do Vendedor
MORADA C40 Morada do Vendedor
CODPOST C28 Código Postal
IMAGEM C120 Nome do ficheiro de imagem da fotografia do funcionário
EQUIP L Se esta ficha é de equipe ?
LOCAL C43 Localidade da Morada
CPOC C15 Código de SNC
TELEFONE C60 Telefone
EMAIL C100 E-mail
ECOM1 N4 Tabela de Comissões 1
CM1 N4 Supervisor 1
ECOM2 N4 Tabela de Comissões 2
CM2 N4 Supervisor 2
ECOM3 N4 Tabela de Comissões 3
CM3 N4 Supervisor 3
ECOM4 N4 Tabela de Comissões 4
CM4 N4 Supervisor 4
VENSUPER L Se o Vendedor é Supervisor ?
CODREM N3 Cód. de remun. a utilizar para as comissões
AREA C20 Área
SOVESEUMX L Se só pode observar as suas próprias marcações na agenda ?
INACTIVO L Inativo ?
OPEREXT L Operações com o exterior ?
```
### CP_3 — Códigos postais (13 de 13 campos úteis)
```text
RUA C100 Nome da rua
CDPNUM N7 Código postal
CDPALF C50 Desc.Cód.Postal
CONCELHO C50 Concelho
LOCAL C50 Localidade
FREG C150 Freguesia
TIPO C50 Tipo de Arruamento
COMPLEM C100 Lugar/Sítio
MINC C1 Título de dívida Inicial
NMIN N8 Nº de Porta Inicial
MAXC C1 Título de dívida Final
NMAX N8 Nº de Porta Final
CLIENTE C100 Nome do Cliente CTT
```
### FORMASPAGAMENTO — Formas de Pagamento (6 de 6 campos úteis)
```text
CODIGO N3 Codigo para identificar o tipo de pagamento
DESCRICAO C60 Descricao da forma de pagamento
DISPONIVELB2B L B2B Disponível no E-Commerce B2B ?
INATIVO L Inativo ?
METODO N3 Metodo de pagamento
MENSAGEM C255 Mensagem a mostrar na modal de pagamentos
```
### SZ — Nomes de Armazéns (11 de 11 campos úteis)
```text
NO N5 Número do Armazém
NOME C30 Nome do Armazém
NOMECL C55 Nome do Cliente
NOCL N10 Número do Cliente
ESTABCL N3 Estabelecimento do Cliente
SITE C20 Loja
COMPRIMENTO N9 Comprimento do armazém
LARGURA N9 Largura do armazém
ALTURA N9 Altura do armazém
CENTROLOG C50 Centro de logística do armazém
STATION_NR C6 Nº da Estação
```
### BC — Códigos de Barras (7 de 7 campos úteis)
```text
REF C18 Referência do artigo
DESIGN C60 Designação do artigo
CODIGO C40 Código de Barras
STSTAMP C25 Ligação a stocks
DEFEITO L Código de Barras por defeito ?
EMB C60 Embalagem
QTT N13.3 Quantidade
```
### SC — Artigos Compostos (13 de 13 campos úteis)
```text
REF C18 Referência do Componente
REFB C18 Ligação a stocks
QTT N13.3 Quantidade
STSTAMP C25 Ligação a stocks
DESIGN C60 Designação do Componente
NOSERIE L Número de Série ?
OBS C60 Observações
RENDIM N13.3 Rendimento
OFCSTAMP C25 Ligação ao OFC
TEMFX L Se tem fórmulas ?
DESCFX C60 Designação da fórmula
ECUSTOF N19.6 Euros: Custo final [legado PTE: CUSTOF]
LORDEM N10 Ordem
```

## 5. Diretório das tabelas relevantes

Uma linha por tabela (nome e descrição). Ficam de fora as cópias temporárias (buffer), as tabelas de interface, portal e afins, e as tabelas sem campos (listas de apoio `A_*`). As de interface continuam no `phc-dicionario.txt`.

```text
FAC Contratos de Factoring
FACA Adiantamentos de Contratos de Factoring
FACALI Detalhe dos adiantamentos de Contratos de Fac
FACC Cessões de Crédito
FACD Devoluções de Cessões de Crédito
FACDL Linhas de Devoluções de Cessões de Crédito
FACL Linhas das Cessões de Crédito
FACP Plano Pagamentos das Cessões de Crédito
FAL Linhas dos Contratos de Factoring
MODCONTRATOSS Modalidades de contrato para a S.S. Direta
AC Acessos a Campos para Mapas definidos por uti
ACL Acessos a Campos para Mapas definidos por uti
AG Entidades
AGSTC Artigos de Custo das Tarefas Agendadas
AGT Tarefas Agendadas
ALG Algoritmos Inteligentes
ALGJS Tabela de justificações simples
ALWCOB Importação via Bank Conenctor
AMENU Acessos especiais dos Utilizadores
ANOSPC Anos da Contabilidade
APROV Sistema de Aprovações
ARF Área Funcional
ATRIB Atributos
AVLEGAL Aviso Legal
AVS Avisos
BA Movimentos em Contas de Tesouraria
BANCOS Bancos
BC Códigos de Barras
BE Ativos
BEANA Plano Analítico
BECC Distribuição de Ativos por Centro Analítico
BEFRX Mapas de Depreciações de Bens
BEIC Inventário Fisico de Ativos
BEIL Linhas de Inventário Fisico de Ativos
BG Garantias Bancárias (Tesouraria)
BI Linhas de Dossiers Internos
BI2 Linhas de Dossiers Internos - Outros Dados
BIPRECAT Linhas de Pré-Cativos de Dossiers Internos
BL Contas de Tesouraria
BO Dossiers Internos
BO2 Dossiers Internos - Outros Dados
BO3 Dossiers Internos - Informação Complementar
BOAUTO Configurações para Emissão Automática de Doss
BOMA Nºs de série de dossiers
BOT Totais dos dossiers internos
BOTXT Diálogos das encomendas
BR Movimentos Bancários Importados
BRULE Regras do utilizador
BT Ficheiro de Depreciações
BV Ficheiro de Reavaliações
BVFRX Mapas de Reavaliações de Bens
BX Extratos Bancários
C9 Imputações de Contas
CALFIS Datas do Calendário Cegid PHC
CALG Casos de Algoritmos Inteligentes
CAMPOS Campos de tabelas
CAVS Configuração de avisos automáticos
CAVSL Linhas Sistema de Configuração de Avisos por 
CB Taxas de conversão para o Euro
CBB Cobranças via Banco
CBBL Movimentos de Cobranças via Banco
CBDC Canais de Broadcast
CBPAISES Moedas e Câmbios
CC C/Correntes Clientes e Entidades
CCE Configuração de contas de Email
CCFC Ficheiro de Encontros de Contas
CCFCL Linhas do Ficheiro de Encontros de Contas
CCT Centros de Custo Geral
CE Fórmulas dos Mapas de Gestão
CECOPE Códigos de Classificação Estatística
CEVAR Variáveis para Fórmulas dos Mapas de Gestão
CF Coeficientes Anuais
CFI Configuração de colunas a integrar na contabi
CH Tabela de títulos de Tesouraria
CHAMADAS Chamadas Telefónicas a Entrar
CHF Títulos emitidos
CHFL Movimentos de Títulos emitidos
CHL Linhas de Títulos de Tesouraria
CI Imputações de Centros de Custo
CIE Integração de Dados
CIS Códigos de Imposto de Selo
CL Clientes
CL2 Clientes - Outros Dados
CLINT Intervalos de Saldos de Cliente
CLW Custos Extra da Loja
CLWL Custos Extra da Loja - Linhas
CM Correções Monetárias
CM1 Códigos de movimentos de c/c
CM2 Códigos de movimentos de stocks
CM3 Vendedores
CM6 Tabela de Códigos para Vencimentos
CNCT Conceitos de Contabilidade para Mapas
CO Cobranças a Clientes
COB Configuração de contas bancárias
COBH Histórico de autenticações no banco
COBI Contas do banco
CODLOG Log de Código de Utilizador
CODRET Códigos de Retorno PS2
COL Gestão de cobranças (linhas cc)
COPE Comunicação de Operações e Posições com o Ext
COPEL Linhas de Comunicação de Operações e Posições
COPELD Documentos de Linhas de Comunicação de Operaç
CPICAI Perdas em Créditos/Ajustamentos em Inventário
CPOC Códigos de Integração de Vendas
CPOO Códigos de Integração de Compras
CPOO2 Códigos de Integração de Compras - Outros Dad
CPSL Códigos de Interligação de Stocks
CP_3 Códigos postais
CR Correspondência
CRVAL Tabela de critérios de validação
CRVALI Linhas dos critérios de validação
CTX Contextos de Dados
CU Centros de Custo da Contabilidade
DC Documentos predefinidos
DCLI Documentos predefinidos , linhas
DFCL Descontos por Artigo / Cliente
DFFL Descontos por Familia / Fornecedor
DFFO Descontos por Artigo / Fornecedor
DI Diários
DIM Dimensões
DISP Dispositivos
DISPACCESS Gestão de dispositivos
DO Documentos Contabilisticos
DQ Descontos por Quantidade / Valor
DSTAXASIVA Taxas de iva de despesas
DTL Ligações entre Tabelas do Dicionário de dados
DYTABLE Tabelas Auxiliares
E1 Ficha completa da Empresa
E1CA Variáveis Cabeçalho
E1LI Variáveis Linhas
E2 Dados Contabilísticos da Empresa
E4 Tabela e-GAR associada ao estabelecimento
EBK Apontamentos Pessoais
EC Sociedades
ECA Configuração dos Destinatários
ECAM Campos Internos
ECGS Utilizadores das Sociedades
ECL Sociedades Participantes
ECLAJ Ajustamentos das Sociedades
ECOM Tabela de Comissões
EDIHISTCOM Histórico da comunicação dos Documentos eletr
EDO Documentos Partilhados
EFAQ Perguntas Frequentes
EFATBACKUP Histórico de importações efatura
EFK Historial
ENU Numeradores do utilizador
EPS Press Release
EREG Regras Internas
ERSS RSS do utilizador
ESCCL Contratos de Rappel a Clientes (escalões)
ESPAPHIST Resultado de comunicação de documentos eletró
EST Catálogo de Produtos
ESTLI Imagens do Catálogo de Produtos
ETP Tarefas Pessoais
ETPB Templates Básicos
ETPL Templates de Tabela
EV Apuramento de CMV
EVENTOS Eventos
EWK Wikis
EWKV Votos em Wikis
EWP Páginas Internet
EXEV Últimas Versões
EXPLORADOR Explorador de dados
EXPLORADORCMP Campos de cálculo do explorador de dados
EXPLORADORFIL Linhas de filtro do explorador de dados
EXPLORADORGRP Linhas de agrupamento do explorador de dados
EXPLORADORORD Linhas de ordenação do explorador de dados
EXPLORADORTOT Linhas de totalizadores do explorador de dado
FAMEM Membros da Comunidade
FAMLI Livro da Comunidade
FAMNW Noticias da Comunidade
FAMPA Páginas da Comunidade
FAMRE Reportagens da Comunidade
FAQF Ficheiros das Perguntas Frequentes
FASC Configuração de Ficheiros
FASCL Campos de ficheiros ASCII
FC Contas Correntes de Fornecedores
FE Fechos de caixa
FEU Filtros de Utilizador
FF Tabela de Feriados
FI Linhas de Documentos de Faturação
FI2 Linhas de Documentos de Faturação - Outros Da
FIVA Formulas do plano de IVA
FL Fornecedores
FLCM1 Serie associada ao Fornecedor/Cliente
FLINT Intervalos de Saldos de Fornecedor
FLST Referências por fornecedor
FN Linhas de Compras a Fornecedores
FO Compras a Fornecedores
FO2 Compras a Fornecedores - Outros Dados
FOFC Pagamentos de Documentos de Compra
FOMA Nºs de série de docs. compra
FOPD Adiantamentos de Documentos de Compra
FORMASPAGAMENTO Formas de Pagamento
FOT Totais dos documentos de compras
FPAGA Custo da forma de pagamento da Loja
FPAGAL Custo da forma de pagamento da Loja - Linhas
FREF Referência Interna
FT Documentos de Faturação
FT2 Documentos de Faturação - Outros Dados
FT3 Documentos de Faturação - Informação compleme
FTCC Pagamentos de Documentos de Faturação
FTMA Nºs de série de docs. faturação
FTRD Regularização de Documentos de Faturação
FTREG Regularizações de Documentos de Faturação
FTT Totais dos documentos de faturação
FTU Funções TSQL do Utilizador
FXBASE Procedimentos do utilizador em XBASE
FXU Funções de utilizador
GAEC Grupos de Acessos Externos (Cabeçalhos)
GAEL Grupos de Acessos Externos (Linhas)
GAELN Grupos de Acessos Externos (Linhas 2)
GESTEXP Exportações de Documentos
GMENU Acessos dos Grupos de Utilizadores
GPNAV Grupos de Opções de Navegação e SnapShots
GSEC Grupos de Sincronização Externos (Cabeçalhos)
GSEL Grupos de Sincronização Externos (Linhas)
GSELN Grupos de Sincronização Externos (Linhas 2)
GT Grelha de Transição
GTXT Comentários
HCODRET Histórico de Códigos de Retorno
HISTAVLEGAL Histórico de aceitação do Aviso Legal
HISTEFATURA Histórico de importação e-fatura
HISTEFATURAL Linhas do histórico de importação e-fatura
HISTMG Histórico de mapas de gestão
HISTPHCATUAL Histórico das atualizações Settings Update
HISTRU Histórico das comunicações do Relatório Único
HISTSSF Histórico das comunicações com a SS Direta
HSEPACRET Histórico de Códigos de Retorno SEPA
IFL Imagens e outros ficheiros internos
IL Linhas Imputações de Centros de Custo
IMP Imparidade
INQ Formulários Dinâmicos
INQL Questões de Formulários Dinâmicos
INTRE Reportagens da Intranet
INTU Instruções Internas
IV Códigos de IVA
JSU Javascript de utilizador
JT Ajustes Fiscais
L9 Linhas de Imputações de Contas
LE Regularizações de Títulos de Dívida a Receber
LG Regularizações de Títulos de Dívida a Pagar
LI Regularizações de Títulos de Dívida a Receber
LL Regularizações de Títulos de Dívida a Pagar,l
LM Títulos de Dívida a Receber, linhas
LO Títulos de Dívida a Pagar,linhas
LOGERR Log de Erros Internos
LOGS Log de Erros
LOJAPAY Pagamentos online via Geral
LP Títulos de Dívida a Pagar
LPD Lei de proteção de dados
LPICAI Movimentos Perdas em Créditos/Ajustamentos em
LR Títulos de Dívida a Receber
LS Plano Financeiro
LT Ligações entre tabelas
LTLI Linhas de Ligações entre tabelas
LV Tabela de Lojas
MA Equipamentos
MAPAS Mapas de Ativos
MC Contabilidade Orçamental
MCA Movimentos Contabilísticos do Ano Anterior
MEC Mapas das Sociedades
MG Mensagens inter-utilizadores
MGDISK Mapas Gestão em Suporte Informático, Cabeçalh
MGDISKL Mapas Gestão em Suporte Informático, Linhas
MGE1CFG Mapas de Gestão, Configuração
MGE1CFGS Mapas de Gestão, Configuração das Secções
MISEIMP Motivos de Isenção de Imposto
ML Movimentos Contabilisticos
MODWEB Opções para Obrigações Periódicas
MPT Tabela de Mapeamento
MSERIESREG Séries de registos criadas via Multiplicador
MVINC Imparidades prazos de mora
MX Marcações
MXAC Acessos a agenda pessoal
MXAREA Áreas das marcações
MXDV Áreas de Marcações
MXUS Utilizadores de marcações
NABDR Notas às Demonstrações Financeiras
NABDRL Linhas das Notas às Demonstrações Financeiras
NCT Naturezas (Geral)
NEC Necessidades
NECC Linhas Necessidades Conteúdo
NECE Necessidades Específicas
NECEC Linhas Necessidades Específicas Conteúdo
NECEL Linhas Necessidades Específicas Checklist
NECL Linhas Necessidades Checklist
NI Imputações de Naturezas
NL Linhas Imputações de Naturezas
NLOG Log de Utilizadores
NOTIFYUSDEVICES Dispositivos de autenticação PHC Notify
NP Naturezas do Plano
NPD Notas pré-definidas
NTF Notificações
OC Códigos de Tesouraria
OD Previsões de Tesouraria
OL Movimentos de tesouraria
OLBB Trf. Conta-Conta
OLBC Trf. Conta-Caixa
OM Movimentos Constantes de Tesouraria
OMENU Opções especiais disponíveis
OP Orçamento de Tesouraria
OUN Opções de Navegação
OUNL Opções de Navegação (Gráfico - Ordenadas)
OUNP Opções de Navegação (Procuras)
OUTROSFI Outras ligações das linhas de documentos de f
OV Objectivos de Vendas
OW Documentos de tesouraria
OWLI Linhas de Documentos de tesouraria
OX Talões de Depósito
OY Linhas de Talões de Depósitos
OZ Processos de tesouraria
PAISES Tabela de Países
PARA1 Parâmetros do Sistema
PARAU Parâmetros do Utilizador
PC Plano de Contas
PCSA Plano de Contas - Saldos
PD Adiantamentos a Fornecedores
PDU Painéis de Informação
PDUP Páginas de Painéis de Informação
PDUU Utilizadores de Painéis de Informação
PF Perfis de Acesso
PFG Grupos de Utilizadores de Perfis de Acesso
PFPROG Produtos por grupo de acesso
PFU Utilizadores de Perfis de Acesso
PIN Procedimentos Internos
PL Linhas de Pagamentos a Fornecedores
PN Produtos vendidos
PO Pagamentos a Fornecedores
POCHF Títulos emitidos de Pagamentos a Fornecedores
POSEXP Exportações para POS
POT Totais dos Pagamentos a Fornecedores
PP Plano de Contas Paralelo
PPPAYMENTS Pagamentos online via PAYPAL
PPSB Subscrições via PAYPAL
PREC Processamentos das Sociedades
PRNC Configurações de Impressora
PRNL Configurações de Impressora, Linhas
PROCASYNC Processamentos Assíncronos
PROCASYNCL Linhas de Processamentos Assíncronos
QFLL Tipos de Artigos de Qualidade de Fornecedores
QUC Questionários
QUP Perguntas dos Questionários
QUPD Acessos aos questionários nos Packages Digita
QUR Respostas aos Questionários
RBDR Rubricas das Demonstrações Financeiras
RD Recibos de adiantamentos
RE Recibos para Clientes
RECH Títulos de Recibos para Clientes
REGIVA Regimes de IVA
REL Relações entre tabelas
RELCONFIG Configuração de Relatórios de Crédito
RELCRED Relatórios de Crédito
RELCREDLI Linhas de Relatórios de Crédito
REREV Recibos para Clientes - Revogações e processa
RET Totais dos Recibos para Clientes
REV Revalorizações
RL Linhas de Recibos para Clientes
RN Rubricas das Notas às Demonstrações Financeir
RPCL Contratos de Rappel a Clientes
RPEC Processos Interop
RPFL Contratos de Rappel a Fornecedores
RS Apuramento de Resultados
RT Artigos Alternativos
RV Apuramento de IVA
SA Stock por Armazém
SAL Stock por Lote/Armazém
SAX Stock por Armazém Global
SBI Tabelas para busca instantânea
SBID Dados para busca instantânea
SC Artigos Compostos
SCD Scorecards
SCDIN Indicadores de Scorecards
SDDAUT Autorizações de Débito em Conta
SE Lotes
SEPACRET Códigos de Retorno SEPA
SERIEAT Séries de documentos na AT
SFCNOME Tabela de Grelhas Tipo de Cores
SFCOR Grelhas tipo - cores
SFTAM Grelhas tipo - tamanhos
SFTNOME Tabela de Grelhas Tipo de Tamanhos
SGC Grelhas dos artigos - cores
SGT Grelhas dos artigos - tamanhos
SL Movimentos de Stock
SO Imposto de selo de títulos de dívida
SP Promoções
SPP Tipos de promoções pré-definidas
SPPV Variáveis de Tipos de promoções pré-definidas
ST Stocks e Serviços
STACKTIMER Documentos Assíncronos Por Processar
STC Artigos de Custo
STCAT Configuração de categorias de artigos
STFAMI Famílias de Artigos
STFOR Fórmulas Para Gestão de Stocks
STIC Inventário Fisico
STIL Linhas de Inventário Fisico
STOBS Observações de Stocks e Serviços
STREL Configuração dos artigos relacionados
STT Configuração de Títulos de Dívida
SV Movimentos de Valor em Stock
SX Informação por cor e tamanho
SXX Stock por Armazém, Cor e Tamanho Global
SZ Nomes de Armazéns
SZADRS Moradas de Carga e Descarga
TABVERSAO Versões de Tabelas
TAXASIVA Taxas de IVA
TAXONOMIAS Tabela de taxonomia
TBPR Tabelas de preços
TBPRI Linhas das Tabelas de preços
TC Teclas do utilizador
TD Configuração de Documentos de Faturação
TD2 Configuração de Documentos de Faturação - Out
TDESP Tipos de Despesa
TFCLA Tabela de classes para artigos com TaxFree
TFGBLUESRV Tabela de configuração GlobalBlue com TaxFree
TI Teclas do utilizador (linhas)
TIPOEMP Tipo de Empresa
TL Decretos Lei de Reavaliações
TN Chamadas telefónicas
TP Condições de Pagamento
TPDIST Tipos de distintivos
TPDISTL Distintivos
TPEMAIL Templates de e-mail
TPFF Tabela Tipos de Feriados
TPIMP Condições de Pagamento de Documentos Importad
TPL Condições de Pagamento para Multi-Pagamento
TR Textos rápidos para campos de texto (memo)
TS Configuração de Dossiers Internos
TS2 Configuração de Dossiers Internos - Outros Da
TSRD Configuração de Recibos de adiantamento para 
TSRE Configuração de Recibos de c/c para Clientes
TT Templates
TTL Registos de Templates
TU Tabelas do utilizador
TUCA Tabelas do utilizador - campos
TZ Códigos de Amortização
VF Campos Virtuais de Relatório
VL Linhas de Pagamentos a Vendedores
VMENU Acessos disponíveis
VOICECOMREC RecentesPHCVoice
VY C/Correntes Vendedores
VYDOC Documentos de C/Correntes Vendedores
VZ Pagamentos a Vendedores
VZF Relação zona do Cliente - Fornecedor
WEBPAY Pagamentos online via UNICRE
WK Workflow Operacional
WKCCOLS Colunas de Cabeçalhos de Documentos de Workfl
WKDOCS Documentos de Workflow Operacional
WKLCOLS Colunas de Linhas de Documentos de Workflow O
WR Relatórios
XD Configuração de documentos XML
XDE Extensões de Documentos XML
XDL Linhas de Documentos XML
XE Exportação de Tabelas
XFT Configuração de Faturação Personalizada
```

## 6. O que foi removido e limites

- Removido do livro: linhas repetidas (a maior parte do ficheiro), 5 669 campos de 58 tabelas buffer, 2 240 campos de auditoria, 2 538 partes de datas, 930 campos legados em escudos (ficou o campo em euros) e 79 campos sem descrição útil.
- O dicionário não tem as chaves próprias (`<tabela>STAMP`), índices, chaves estrangeiras, triggers nem valores por defeito.
- Não tem tabelas nem campos `u_*`.
- Pode não ser exaustivo: por exemplo, não encontrei `ST.UNIDADE`. `[CONFIRMAR]` na base.
- Em campos em série (por exemplo `BO71_BINS`) o livro tinha várias descrições; ficou a primeira. O nome, o tipo e o tamanho não mudam.
- "Não está no dicionário" não prova que não exista. Confirma sempre com uma consulta de leitura na base de testes.

## 7. Atualizar

Quando o cliente tiver outra versão do PHC e outro livro Excel: `python docs/phc/gerar-dicionario.py livro.xlsx docs/phc` (precisa de `pip install openpyxl`). Gera `phc-dicionario.txt` e `phc-diretorio.txt`. Se a versão for diferente, guarda-os com a versão no nome da pasta (por exemplo `docs/phc/<versão>/`) e o prompt diz qual usar. O essencial (secção 4) só se altera à mão, a pedido.
