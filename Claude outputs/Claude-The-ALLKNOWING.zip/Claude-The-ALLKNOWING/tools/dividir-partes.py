#!/usr/bin/env python3
# Divide projeto/projeto-sigmacode.md (o ficheiro único do Projeto Claude) em normas/NN-nome.md,
# um ficheiro por parte, mais normas/00-indice.md. Corre-se sempre que o ficheiro único muda.
# Uso:  python tools/dividir-partes.py
import os
import re

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORIGEM = os.path.join(RAIZ, 'projeto', 'projeto-sigmacode.md')
DESTINO = os.path.join(RAIZ, 'normas')
NOMES = {1: 'instrucoes-projeto', 2: 'contexto-stack', 3: 'convencoes-codigo', 4: 'catalogo-tasks',
         5: 'modelo-task-global', 6: 'modelo-prompt', 7: 'exemplo-otimizacao', 8: 'dicionario-phc', 9: 'agentes'}

texto = open(ORIGEM, encoding='utf-8').read()
partes = re.split(r'\n\n---\n\n(?=# Parte \d+ — )', texto)[1:]  # o 1.º bloco é o cabeçalho do ficheiro
os.makedirs(DESTINO, exist_ok=True)
indice = ['# Índice das normas', '', 'Cada ficheiro é uma "Parte" do ficheiro único do Projeto Claude. As referências "Parte N" nos textos apontam para estes ficheiros.', '']
for p in partes:
    n = int(re.match(r'# Parte (\d+)', p).group(1))
    titulo = p.split('\n', 1)[0].lstrip('# ').strip()
    nome = '%02d-%s.md' % (n, NOMES[n])
    with open(os.path.join(DESTINO, nome), 'w', encoding='utf-8', newline='\n') as f:
        f.write(p.strip('\n') + '\n')
    indice.append('- `%s`: %s' % (nome, titulo))
with open(os.path.join(DESTINO, '00-indice.md'), 'w', encoding='utf-8', newline='\n') as f:
    f.write('\n'.join(indice) + '\n')
print('Partes escritas:', len(partes))
